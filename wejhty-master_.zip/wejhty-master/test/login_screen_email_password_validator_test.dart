import 'package:flutter_test/flutter_test.dart';
import 'package:wejhty/view/auth/login/login_screen.dart';
import 'package:wejhty/view/auth/resetPassword/reset_password_screen.dart';

void main() {

  test('empty email returns error string', () {

    final result = EmailFieldValidators.validate('');
    expect(result, 'Email can\'t be empty');
  });

  test('non-empty email returns null', () {

    final result = EmailFieldValidators.validate('email');
    expect(result, null);
  });

  test('empty password returns error string', () {

    final result = PasswordFieldValidator.validate('');
    expect(result, 'Password can\'t be empty');
  });

  test('non-empty password returns null', () {

    final result = PasswordFieldValidator.validate('password');
    expect(result, null);
  });
}