import 'package:flutter_test/flutter_test.dart';
import 'package:wejhty/view/auth/resetPassword/reset_password_screen.dart';

void main() {

  test('empty email returns error string', () {

    final result = EmailFieldValidator.validate('');
    expect(result, 'Email can\'t be empty');
  });

  test('non-empty email returns null', () {

    final result = EmailFieldValidator.validate('email');
    expect(result, null);
  });


}