import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../../helper/global_data.dart';

class CustomListTile extends StatefulWidget {
  final Widget? trailing;
  final String? title;
  final TextStyle? titleStyle;
  final String? subTitle;
  final String? subTitle2;
  final TextStyle? subTitleStyle;
  final TextStyle? subTitle2Style;
  final Widget? leading;
  final Color? borderColor;
  final VoidCallback? onPressed;
  final double? size;
  final double? contentSpacing;
  final EdgeInsets? padding;
  final Color? tileColor;

  const CustomListTile(
      {key,
      this.trailing,
      this.title,
      this.titleStyle,
      this.subTitle,
      this.subTitle2,
      this.subTitleStyle,
      this.subTitle2Style,
      this.leading,
      this.borderColor,
      this.onPressed,
      this.size,
      this.contentSpacing,
      this.padding,
      this.tileColor})
      : super(key: key);

  @override
  _CustomListTileState createState() => _CustomListTileState();
}

class _CustomListTileState extends State<CustomListTile> {
  @override
  Widget build(BuildContext context) {
    ColorScheme colorScheme = Theme.of(context).colorScheme;
    return widget.onPressed != null
        ? CupertinoButton(
            minSize: 45,
            borderRadius: BorderRadius.circular(0),
            padding: const EdgeInsets.all(0),
            onPressed: widget.onPressed,
            child: Container(
              margin: const EdgeInsets.only(bottom: 1),
              constraints: const BoxConstraints(minHeight: 45, minWidth: double.infinity),
              padding: widget.padding ??
                  const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
              alignment: Alignment.centerLeft,
              decoration: BoxDecoration(
                  border: Border(
                    bottom: BorderSide(
                        color: widget.borderColor != null
                            ? widget.borderColor!
                            : cs.onSecondary.withOpacity(0.1),
                        width: 1),
                  ),
                  color: widget.tileColor ?? colorScheme.onPrimary),
              width: widget.size,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  widget.leading != null ? widget.leading! : Container(),
                  SizedBox(
                    width: widget.contentSpacing ?? 10.0,
                  ),
                  Expanded(
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        widget.title != null
                            ? Container(
                          width: double.infinity,
                              child: Text(
                                  "${widget.title}",
                                  style: widget.titleStyle ??
                                      TextStyle(
                                          color: cs.onSecondary,
                                          fontSize: 14,
                                          fontWeight: FontWeight.w400),
                                ),
                            )
                            : Container(),
                        widget.subTitle != null
                            ? Container(
                                width: double.infinity,
                                padding: const EdgeInsets.only(top: 5),
                                child: Text(
                                  "${widget.subTitle}",
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: widget.subTitleStyle ??
                                      TextStyle(
                                          color: cs.onSecondary,
                                          fontSize: 16,
                                          fontWeight: FontWeight.w400),
                                ),
                              )
                            : Container(),
                        widget.subTitle2 != null
                            ? Padding(
                                padding: const EdgeInsets.only(top: 5),
                                child: Text(
                                  "${widget.subTitle2}",
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: widget.subTitle2Style ??
                                      TextStyle(
                                          color: cs.onSecondary,
                                          fontSize: 16,
                                          fontWeight: FontWeight.w400),
                                ),
                              )
                            : Container(),
                      ],
                    ),
                  ),
                  SizedBox(
                    width: widget.contentSpacing ?? 10.0,
                  ),
                  widget.trailing != null
                      ? widget.trailing!
                      : CircleAvatar(
                          backgroundColor: colorScheme.onSurface,
                          radius: 10,
                          child: const Icon(
                            CupertinoIcons.right_chevron,
                            size: 12,
                          ),
                        ),
                ],
              ),
            ),
          )
        : Container(
            margin: const EdgeInsets.only(bottom: 1),
            constraints: const BoxConstraints(minHeight: 45, minWidth: double.infinity),
            padding:
                widget.padding ?? const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
            alignment: Alignment.centerLeft,
            decoration: BoxDecoration(
                border: Border(
                  bottom: BorderSide(
                      color: widget.borderColor != null
                          ? widget.borderColor!
                          : cs.onSecondary.withOpacity(0.1),
                      width: 1),
                ),
                color: widget.tileColor ?? colorScheme.onPrimary),
            width: widget.size,
            child: Row(
              children: [
                widget.leading ?? Container(),
                SizedBox(
                  width: widget.contentSpacing ?? 10.0,
                ),
                Expanded(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      widget.title != null
                          ? Text(
                              "${widget.title}",
                              style: widget.titleStyle ??
                                  TextStyle(
                                      color: cs.onSecondary,
                                      fontSize: 14,
                                      fontWeight: FontWeight.normal),
                            )
                          : Container(),
                      widget.subTitle != null
                          ? Padding(
                              padding: const EdgeInsets.only(top: 5),
                              child: Text(
                                "${widget.subTitle}",
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: widget.subTitleStyle ??
                                    TextStyle(
                                        color: cs.onSecondary,
                                        fontSize: 16,
                                        fontWeight: FontWeight.w400),
                              ),
                            )
                          : Container(),
                      widget.subTitle2 != null
                          ? Padding(
                              padding: const EdgeInsets.only(top: 5),
                              child: Text(
                                "${widget.subTitle2}",
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: widget.subTitle2Style ??
                                    TextStyle(
                                        color: cs.onSecondary,
                                        fontSize: 16,
                                        fontWeight: FontWeight.w400),
                              ),
                            )
                          : Container(),
                    ],
                  ),
                ),
                SizedBox(
                  width: widget.contentSpacing ?? 10.0,
                ),
                widget.trailing != null
                    ? widget.trailing!
                    : CircleAvatar(
                        backgroundColor: colorScheme.onSurface,
                        radius: 12,
                        child: const Icon(
                          CupertinoIcons.right_chevron,
                          size: 14,
                        ),
                      ),
              ],
            ),
          );
  }
}
