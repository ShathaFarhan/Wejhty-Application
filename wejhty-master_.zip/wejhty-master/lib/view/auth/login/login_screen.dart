import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:wejhty/routes/page_route.dart';

import '../../../helper/global_data.dart';
import '../../../services/auth_service.dart';



class EmailFieldValidators {
  static String? validate(String value) {
    return value.isEmpty ? 'Email can\'t be empty' : null;
  }
}
class PasswordFieldValidator {
  static String? validate(String value) {
    return value.isEmpty ? 'Password can\'t be empty' : null;
  }
}
class LoginScreen extends StatelessWidget {
  final VoidCallback? onSignedIn;
  static const String routeName = '/loginScreen';

  const LoginScreen({Key? key, this.onSignedIn}) : super(key: key);

  static final TextEditingController _emailController = TextEditingController();
  static final TextEditingController _passwordController =
      TextEditingController();

  _login(context) {
    String email = _emailController.text.trim();
    String password = _passwordController.text.trim();
    if (!GlobalData.emailRegExp.hasMatch(email.trim()) || password.isEmpty) {
      EasyLoading.showToast('All fields are mandatory.',
          duration: const Duration(seconds: 1));
      return;
    }
    FocusScope.of(context).unfocus();
    AuthService().signInWithEmailAndPassword(email, password);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cs.primary,
      resizeToAvoidBottomInset: false,
      body: Stack(
        children: [
          Column(
            children: [
              Expanded(
                flex: 1,
                child: Container(),
              ),
              Expanded(
                flex: 1,
                child: Container(
                  decoration: BoxDecoration(
                      color: cs.secondary,
                      borderRadius: BorderRadius.vertical(top: Radius.circular(size.width * 0.2))),
                ),
              )
            ],
          ),
          Scaffold(
            backgroundColor: Colors.transparent,
            resizeToAvoidBottomInset: true,
            appBar: AppBar(backgroundColor: cs.primary, elevation: 0),
            body: SafeArea(
              child: ListView(
                children: [
                  SizedBox(
                    width: size.width,
                    height: size.height - AppBar().preferredSize.height,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          "Welcome Back\nWe Missed You!",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              color: cs.secondary,
                              fontWeight: FontWeight.bold,
                              fontSize: 32),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Text(
                          "EXPLORE THE WORLD",
                          style: TextStyle(
                              color: cs.secondary,
                              letterSpacing: 1.2,
                              fontWeight: FontWeight.w400,
                              fontSize: 14),
                        ),
                        SizedBox(
                          width: size.width * 0.8,
                          child: Card(
                            elevation: 8,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(24)),
                            color: cs.onPrimary,
                            margin: const EdgeInsets.only(top: 24),
                            child: Padding(
                              padding: EdgeInsets.symmetric(
                                  vertical: size.height * 0.05, horizontal: 16),
                              child: Column(
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Column(
                                        crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            "Login",
                                            style: TextStyle(
                                                color: cs.primary,
                                                fontWeight: FontWeight.bold,
                                                fontSize: 24),
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.only(
                                                top: 5, bottom: 24),
                                            child: SizedBox(
                                                width: 60,
                                                child: Divider(
                                                  height: 3,
                                                  color: cs.primary,
                                                  thickness: 3,
                                                )),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 40,
                                    child: CupertinoTextField(
                                      placeholder: EmailFieldValidators.validate(_emailController.text),
                                      controller: _emailController,
                                      keyboardType: TextInputType.emailAddress,
                                      textInputAction: TextInputAction.next,
                                      decoration: BoxDecoration(
                                          border: Border.all(
                                              color: cs.primary, width: 2),
                                          borderRadius:
                                          BorderRadius.circular(20)),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 20,
                                  ),
                                  SizedBox(
                                    height: 40,
                                    child: CupertinoTextField(
                                      placeholder: PasswordFieldValidator.validate(_passwordController.text),
                                      controller: _passwordController,
                                      keyboardType: TextInputType.visiblePassword,
                                      textInputAction: TextInputAction.done,
                                      obscureText: true,
                                      decoration: BoxDecoration(
                                          border: Border.all(
                                              color: cs.primary, width: 2),
                                          borderRadius:
                                          BorderRadius.circular(20)),
                                    ),
                                  ),
                                  SizedBox(
                                    height: size.height * 0.03,
                                  ),
                                  SizedBox(
                                      width: size.width * 0.5,
                                      child: CupertinoButton(
                                          onPressed: () {
                                            _login(context);
                                          },
                                          padding: const EdgeInsets.all(5),
                                          color: cs.primary,
                                          child: const Text("LOG IN",
                                              style: TextStyle(
                                                letterSpacing: 1.2,
                                              )))),
                                  Padding(
                                    padding: const EdgeInsets.only(top: 16),
                                    child: SizedBox(
                                        width: size.width * 0.5,
                                        child: Divider(
                                          height: 2,
                                          color: cs.primary,
                                          thickness: 2,
                                        )),
                                  ),
                                  CupertinoButton(
                                      child: Text(
                                        "Forgot Your Password?",
                                        style: TextStyle(
                                            color: cs.secondaryContainer
                                                .withOpacity(0.5),
                                            fontSize: 16),
                                      ),
                                      onPressed: () {
                                        Navigator.pushNamed(context, PageRoutes.resetPassword);
                                      })
                                ],
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}
