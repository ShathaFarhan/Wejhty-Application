import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';

import '../../../helper/global_data.dart';
import '../../../services/auth_service.dart';


class EmailFieldValidator {
  static String? validate(String value) {
    return value.isEmpty ? 'Email can\'t be empty' : null;
  }
}
class ResetPasswordScreen extends StatelessWidget {
  static const String routeName = '/resetPasswordScreen';

  const ResetPasswordScreen({Key? key}) : super(key: key);

  static final TextEditingController _emailController = TextEditingController();

  _reset(context) {
    String email = _emailController.text.trim();
    if (!GlobalData.emailRegExp.hasMatch(email.trim())) {
      EasyLoading.showToast('All fields are mandatory.',
          duration: const Duration(seconds: 1));
      return;
    }
    FocusScope.of(context).unfocus();
    AuthService().resetPassword(email).then((value) {
      if(value){
        _emailController.clear();
        showDialog(context: context,
            builder: (context) => CupertinoAlertDialog(title: Text("Success", style: TextStyle(color: cs.primary),),
              content: Text(
                "Password reset link has been sent to your mail address!", style: TextStyle(color: cs.secondaryContainer, fontSize: 14),), actions: [
                CupertinoDialogAction(child: const Text("OK"), onPressed: () {
                  Navigator.of(context).pop();
                },)
              ],));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cs.primary,
      resizeToAvoidBottomInset: false,
      body: Stack(
        children: [
          Column(
            children: [
              Expanded(
                flex: 1,
                child: Container(),
              ),
              Expanded(
                flex: 1,
                child: Container(
                  decoration: BoxDecoration(
                      color: cs.secondary,
                      borderRadius: BorderRadius.vertical(top: Radius.circular(size.width * 0.2))),
                ),
              )
            ],
          ),
          Scaffold(
            backgroundColor: Colors.transparent,
            resizeToAvoidBottomInset: true,
            appBar: AppBar(backgroundColor: cs.primary, elevation: 0),
            body: SafeArea(
              child: ListView(
                children: [
                  SizedBox(
                    width: size.width,
                    height: size.height - AppBar().preferredSize.height,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          "Reset Password",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              color: cs.secondary,
                              fontWeight: FontWeight.bold,
                              fontSize: 32),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Text(
                          "EXPLORE THE WORLD",
                          style: TextStyle(
                              color: cs.secondary,
                              letterSpacing: 1.2,
                              fontWeight: FontWeight.w400,
                              fontSize: 14),
                        ),
                        SizedBox(
                          width: size.width * 0.8,
                          child: Card(
                            elevation: 8,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(24)),
                            color: cs.onPrimary,
                            margin: const EdgeInsets.only(top: 24),
                            child: Padding(
                              padding: EdgeInsets.symmetric(
                                  vertical: size.height * 0.05, horizontal: 16),
                              child: Column(
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Column(
                                        crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            "Forgot Password",
                                            style: TextStyle(
                                                color: cs.primary,
                                                fontWeight: FontWeight.bold,
                                                fontSize: 24),
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.only(
                                                top: 5, bottom: 24),
                                            child: SizedBox(
                                                width: 160,
                                                child: Divider(
                                                  height: 3,
                                                  color: cs.primary,
                                                  thickness: 3,
                                                )),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 40,
                                    child: CupertinoTextField(
                                      placeholder: EmailFieldValidator.validate(_emailController.text),
                                      controller: _emailController,
                                      keyboardType: TextInputType.emailAddress,
                                      textInputAction: TextInputAction.done,
                                      decoration: BoxDecoration(
                                          border: Border.all(
                                              color: cs.primary, width: 2),
                                          borderRadius:
                                          BorderRadius.circular(20)),
                                    ),
                                  ),
                                  SizedBox(
                                    height: size.height * 0.03,
                                  ),
                                  SizedBox(
                                      width: size.width * 0.5,
                                      child: CupertinoButton(
                                          onPressed: (){
                                            _reset(context);
                                          },
                                          padding: const EdgeInsets.all(5),
                                          color: cs.primary,
                                          child: const Text("RESET",
                                              style: TextStyle(
                                                letterSpacing: 1.2,
                                              )))),
                                  Padding(
                                    padding: const EdgeInsets.only(top: 16),
                                    child: SizedBox(
                                        width: size.width * 0.5,
                                        child: Divider(
                                          height: 2,
                                          color: cs.primary,
                                          thickness: 2,
                                        )),
                                  ),
                                  CupertinoButton(
                                      child: Text(
                                        "Login?",
                                        style: TextStyle(
                                            color: cs.primary,
                                            fontSize: 16),
                                      ),
                                      onPressed: () {
                                        Navigator.of(context).pop();
                                      })
                                ],
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}
