import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:wejhty/helper/global_data.dart';
import 'package:wejhty/routes/page_route.dart';

import '../../services/auth_service.dart';

class AuthScreen extends StatelessWidget {
  static const String routeName = '/authScreen';

  const AuthScreen({Key? key}) : super(key: key);

  _loginAnonymous() {
    AuthService().signInAnonymously();
  }

  @override
  Widget build(BuildContext context) {
    FocusScope.of(context).unfocus();
    return Scaffold(
      backgroundColor: cs.primary,
      body: SafeArea(
        child: Stack(
          children: [
            Column(
              children: [
                Expanded(
                  flex: 1,
                  child: Container(),
                ),
                Expanded(
                  flex: 1,
                  child: Container(
                    decoration: BoxDecoration(
                        color: cs.secondary,
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(size.width * 0.5))),
                  ),
                )
              ],
            ),
            SizedBox(
              width: size.width,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    "WEJHITY",
                    style: TextStyle(
                        color: cs.secondary,
                        fontWeight: FontWeight.bold,
                        fontSize: 32),
                  ),
                  const SizedBox(height: 10,),
                  Text(
                    "EXPLORE THE WORLD",
                    style: TextStyle(
                        color: cs.secondary,
                        letterSpacing: 1.2,
                        fontWeight: FontWeight.w400,
                        fontSize: 14),
                  ),
                  SizedBox(
                    width: size.width * 0.8,
                    child: Card(
                      elevation: 8,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(24)),
                      color: cs.onPrimary,
                      margin: const EdgeInsets.only(top: 24),
                      child: Padding(
                        padding:
                            EdgeInsets.symmetric(vertical: size.height * 0.07),
                        child: Column(
                          children: [
                            SizedBox(
                                width: size.width * 0.5,
                                child: CupertinoButton(
                                    onPressed: () {
                                      Navigator.pushNamed(context, PageRoutes.login);
                                    },
                                    color: cs.primary,
                                    padding: const EdgeInsets.all(5),
                                    child: const Text("LOG IN", style: TextStyle(letterSpacing: 1.2,),))),
                            SizedBox(
                              height: size.height * 0.03,
                            ),
                            SizedBox(
                                width: size.width * 0.5,
                                child: CupertinoButton(
                                    onPressed: () {
                                      Navigator.pushNamed(context, PageRoutes.register);
                                    },
                                    color: cs.primary,
                                    padding: const EdgeInsets.all(5),
                                    child: const Text("SIGN UP", style: TextStyle(letterSpacing: 1.2,)))),
                            SizedBox(
                              height: size.height * 0.03,
                            ),
                            SizedBox(
                                width: size.width * 0.5,
                                child: CupertinoButton(
                                    onPressed: () {
                                      _loginAnonymous();
                                    },
                                    padding: const EdgeInsets.all(5),
                                    color: cs.primary,
                                    child: const Text("JOIN AS GUEST", style: TextStyle(letterSpacing: 1.2,)))),
                          ],
                        ),
                      ),
                    ),
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
