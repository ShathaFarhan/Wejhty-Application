import 'package:calendar_date_picker2/calendar_date_picker2.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:wejhty/main.dart';
import 'package:wejhty/view/dashboard/calender/bookedEvents/booked_events.dart';

import '../../../helper/global_data.dart';
import '../home/bookOrder/order_item.dart';

class CalenderScreen extends StatefulWidget {
  const CalenderScreen({Key? key}) : super(key: key);

  @override
  State<CalenderScreen> createState() => _CalenderScreenState();
}

class _CalenderScreenState extends State<CalenderScreen> {
  static List<DateTime?> _dates = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cs.primary,
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          /// Heading
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "My Calender",
                  style: TextStyle(
                      color: cs.secondary,
                      fontSize: 24,
                      fontWeight: FontWeight.bold),
                ),
                Text(
                  "Find your upcoming events.",
                  style: TextStyle(
                      color: cs.secondary,
                      fontSize: 16,
                      fontWeight: FontWeight.w400),
                )
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: Row(
              children: [
                Expanded(
                    child: Card(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16)),
                  child: CupertinoButton(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 20),
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const BookedEvents(),
                          ));
                    },
                    child: Row(
                      children: [
                        Expanded(
                            child: Text(
                          "All Booked Events",
                          style: TextStyle(
                              fontWeight: FontWeight.w600,
                              color: cs.primary,
                              fontSize: 16),
                        )),
                        const Icon(CupertinoIcons.right_chevron)
                      ],
                    ),
                  ),
                ))
              ],
            ),
          ),
          Card(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            color: cs.secondary.withOpacity(0.3),
            elevation: 5,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: CalendarDatePicker2(
                config: CalendarDatePicker2Config(
                    selectedDayHighlightColor: cs.onPrimary,
                    selectedDayTextStyle: TextStyle(color: cs.onSecondary),
                    calendarType: CalendarDatePicker2Type.range),
                value: _dates,
                onValueChanged: (dates) {
                  setState(() {
                    _dates = dates;
                    logger.d(_dates);
                  });
                },
              ),
            ),
          ),
          const SizedBox(
            height: 16,
          ),
          ...List.generate(
              getDates().length, (index) => getDateItem(getDates()[index]))
        ],
      ),
    );
  }

  List<DateTime?> getDates() {
    if (_dates.length > 1) {
      List<DateTime> days = [];
      for (int i = 0; i <= _dates[1]!.difference(_dates[0]!).inDays; i++) {
        days.add(_dates[0]!.add(Duration(days: i)));
      }
      return days;
    } else {
      return _dates;
    }
  }

  getDateItem(DateTime? dateTime) {
    if (dateTime == null) {
      return Container();
    }
    String date = GlobalData.normalFormat.format(dateTime);
    logger.e("$date, $dateTime");
    return StreamBuilder<QuerySnapshot>(builder: (context, snapshot) {
      if(snapshot.hasData){
        if(snapshot.data != null){
          var dd = snapshot.data!.docs.where((element) => element['status'] != 'canceled').toList();
          if(dd.isNotEmpty){
            return Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    GlobalData.normalFormat.format(dateTime),
                    style: TextStyle(
                        color: cs.secondary, fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  Container(
                    width: 100,
                    height: 6,
                    margin: const EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                        color: cs.secondary, borderRadius: BorderRadius.circular(10)),
                  ),
                  ...List.generate(dd.length, (index) {
                    if(dd[index]['status'] != 'canceled'){
                      return OrderItem(documentSnapshot: dd[index]);
                    }else{
                      return Container();
                    }
                  })
                ],
              ),
            );
          }
        }
      }
      return Container();
    }, stream: FirebaseFirestore.instance.collection('orders').where('book_date', isEqualTo: date).snapshots(),);
  }
}
