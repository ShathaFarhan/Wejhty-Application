import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:wejhty/helper/global_data.dart';

class UpcomingItem extends StatelessWidget {
  final DocumentSnapshot document;
  const UpcomingItem({Key? key, required this.document}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot>(builder: (context, snapshot) {
      if(snapshot.hasData){
        if(snapshot.data != null){
          return SizedBox(
            width: size.width,
            child: Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              color: cs.secondary.withOpacity(0.3),
              elevation: 5,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ClipRRect(
                    borderRadius:
                    const BorderRadius.vertical(top: Radius.circular(16)),
                    child: Image.network(
                      snapshot.data!['Thumbnail'],
                      width: size.width,
                      height: size.width * 0.4,
                      fit: BoxFit.cover,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 10,),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            RatingBar.builder(
                              initialRating: double.parse(snapshot.data!['Ratings'].toString()),
                              minRating: 1,
                              direction: Axis.horizontal,
                              allowHalfRating: true,
                              itemCount: 5,
                              itemSize: 20,
                              ignoreGestures: true,
                              itemPadding: const EdgeInsets.symmetric(horizontal: 2.0),
                              itemBuilder: (context, _) => Icon(
                                Icons.star,
                                color: cs.secondary,
                              ),
                              onRatingUpdate: (rating) {
                                print(rating);
                              },
                            ),
                            Container(
                              decoration: BoxDecoration(
                                  color: cs.onSecondary.withOpacity(0.3),
                                  borderRadius: BorderRadius.circular(5)
                              ),
                              padding: const EdgeInsets.all(5),
                              child: Text("UPCOMING", style: TextStyle(color: cs.secondary, fontSize: 14, fontWeight: FontWeight.w500),),
                            )
                          ],
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          child: Text(snapshot.data!['eventname'],
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                  color: cs.secondary,
                                  fontSize: 24,
                                  fontWeight: FontWeight.w600,
                                  letterSpacing: 1.3)),
                        ),
                        Row(
                          children: [
                            Icon(
                              CupertinoIcons.location_solid,
                              color: cs.onPrimary,
                              size: 18,
                            ),
                            Expanded(
                                child: Text(
                                  snapshot.data!['eventcity'],
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                      color: cs.onPrimary.withOpacity(0.7),
                                      fontSize: 16,
                                      fontWeight: FontWeight.w400),
                                ))
                          ],
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          child: Text(
                            "Event Date: ${GlobalData.normalFormat.format(DateTime.fromMillisecondsSinceEpoch(document['booking_date']))}",
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                                color: cs.onPrimary.withOpacity(0.7),
                                fontWeight: FontWeight.w400,
                                fontSize: 16),
                          ),
                        )
                      ],
                    ),
                  ),
                  if((document.data() as Map<String, dynamic>).containsKey("transport"))
                  Card(
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                    color: cs.secondary.withOpacity(0.3),
                    elevation: 5,
                    margin: const EdgeInsets.only(bottom: 0),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        ClipRRect(
                          borderRadius:
                          const BorderRadius.horizontal(left: Radius.circular(8)),
                          child: Image.network(
                            document['transport']['image'],
                            width: 120,
                            height: 80,
                            fit: BoxFit.cover,
                          ),
                        ),
                        Expanded(
                            child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                children: [
                                  Text(document['transport']['vehicletype'],
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                          color: cs.onPrimary,
                                          fontSize: 20,
                                          fontWeight: FontWeight.w600,
                                          letterSpacing: 1.0)),
                                  const SizedBox(height: 8,),
                                  Text("Vehicle No.: ${document['transport']['vehiclenumber']}",
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                          color: cs.secondary,
                                          fontSize: 16,
                                          fontWeight: FontWeight.w600,
                                          letterSpacing: 1.0)),
                                ],
                              ),
                            )),
                      ],
                    ),
                  )
                ],
              ),
            ),
          );
        }else{
          return Container();
        }
      }else{
        return const Center(child: CircularProgressIndicator(),);
      }
    }, stream: FirebaseFirestore.instance.collection('event').doc(document['eventId']).snapshots(),);
  }
}
