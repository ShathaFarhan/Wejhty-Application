import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:wejhty/main.dart';

import '../../../../../helper/global_data.dart';

class ReviewDialog extends StatelessWidget {
  final String orderId;
  final String eventId;

  const ReviewDialog({Key? key, required this.orderId, required this.eventId})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(builder: (context, snapshot) {
      if(snapshot.hasData){
        if(snapshot.data != null){
          if(snapshot.data!.docs.isEmpty){
            return CupertinoButton(
              onPressed: () {
                showBottom(context);
              },
              color: cs.primary,
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              minSize: 30,
              child: const Text("Write Review"),
            );
          }else{
            return CupertinoButton(
              onPressed: null,
              color: cs.primary,
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              minSize: 30,
              child: Text("Rated: ${snapshot.data!.docs.first['rating']}"),
            );
          }
        }
        return Container();
      }else{
        return Container();
      }
    }, stream: FirebaseFirestore.instance.collection("reviews").where("orderId", isEqualTo: orderId).snapshots(),);
  }

  showBottom(context) {
    return showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      isDismissible: true,
      enableDrag: true,
      useSafeArea: true,
      backgroundColor: cs.secondary,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) {
          TextEditingController textEditingController = TextEditingController();
          double rating = 0.0;
          return Padding(
            padding: MediaQuery.of(context).viewInsets,
            child: BottomSheet(
              onClosing: () {},
              backgroundColor: cs.secondary,
              builder: (context) => Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      "Leave a review",
                      style: TextStyle(
                          color: cs.onSecondary,
                          fontSize: 20,
                          fontWeight: FontWeight.w600),
                    ),
                    Text(
                      "How was your experience?",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: cs.secondaryContainer,
                          fontWeight: FontWeight.w500,
                          fontSize: 16),
                    ),
                    Divider(
                      thickness: 1,
                      height: 32,
                      color: cs.secondaryContainer.withOpacity(0.1),
                    ),
                    Card(
                      color: cs.onPrimary,
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: RatingBar.builder(
                          initialRating: rating,
                          minRating: 1,
                          direction: Axis.horizontal,
                          allowHalfRating: true,
                          itemCount: 5,
                          itemSize: 32,
                          itemPadding: const EdgeInsets.symmetric(horizontal: 10.0),
                          itemBuilder: (context, _) => Icon(
                            Icons.star,
                            color: cs.secondary,
                          ),
                          onRatingUpdate: (ratings) {
                            rating = ratings;
                          },
                        ),
                      ),
                    ),
                    const SizedBox(height: 12,),
                    Row(
                      children: [
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 10),
                            child: Text(
                              "Write Your Review",
                              style: TextStyle(
                                  color: cs.onSecondary,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600),
                            ),
                          ),
                        )
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: CupertinoTextField(
                        controller: textEditingController,
                        textInputAction: TextInputAction.done,
                        decoration: BoxDecoration(
                            color: cs.onPrimary,
                            borderRadius: BorderRadius.circular(12)),
                        placeholder: "Type Review...",
                        maxLines: 3,
                      ),
                    ),
                    const SizedBox(
                      height: 16,
                    ),
                    CupertinoButton(
                      onPressed: () {
                        if (rating <= 0 || textEditingController.text.isEmpty) {
                          EasyLoading.showToast("All fields are mandatory",
                              duration: const Duration(seconds: 1));
                        } else {
                          FirebaseFirestore.instance.collection("reviews").add({
                            "orderId": orderId,
                            "eventId": eventId,
                            "rating": rating,
                            "review": textEditingController.text,
                            "created_at": DateTime.now()
                          }).then((value) => Navigator.of(context).pop());
                        }
                      },
                      color: cs.primary,
                      padding: EdgeInsets.symmetric(
                          horizontal: size.width * 0.05, vertical: 5),
                      child: Text(
                        "Submit Review",
                        style: TextStyle(color: cs.onPrimary),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
