import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:wejhty/helper/global_data.dart';
import 'package:wejhty/view/dashboard/calender/bookedEvents/components/completed_item.dart';
import 'package:wejhty/view/dashboard/calender/bookedEvents/components/upcoming_item.dart';

class BookedEvents extends StatelessWidget {
  const BookedEvents({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: cs.primary,
        appBar: AppBar(
          backgroundColor: cs.primary,
          elevation: 1,
          title: const Text("Booked Events"),
          bottom: PreferredSize(
            preferredSize: Size(size.width, 60),
            child: TabBar(
              unselectedLabelStyle: TextStyle(color: cs.secondaryContainer),
              labelStyle:
                  const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              indicatorColor: cs.secondary,
              indicatorWeight: 5,
              labelColor: cs.secondary,
              tabs: const [
                Tab(
                  text: "Upcoming",
                ),
                Tab(
                  text: "Completed",
                ),
              ],
            ),
          ),
        ),
        body: TabBarView(
          children: [
            StreamBuilder(
              stream: FirebaseFirestore.instance
                  .collection("orders")
                  .where('booking_date',
                      isGreaterThanOrEqualTo: DateTime.now().millisecondsSinceEpoch)
                  .orderBy("booking_date", descending: false)
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  if (snapshot.data != null) {
                    var dd = snapshot.data!.docs.where((element) => element['status'] != 'canceled').toList();
                    return ListView(
                      scrollDirection: Axis.vertical,
                      shrinkWrap: false,
                      padding: const EdgeInsets.all(8),
                      children: List.generate(
                          dd.length,
                          (index) => UpcomingItem(
                              document: dd[index])),
                    );
                  } else {
                    return Container();
                  }
                } else {
                  return const Center(
                    child: CircularProgressIndicator(),
                  );
                }
              },
            ),
            StreamBuilder(
              stream: FirebaseFirestore.instance
                  .collection("orders")
                  .where('booking_date',
                      isLessThanOrEqualTo: DateTime.now().millisecondsSinceEpoch)
                  .orderBy("booking_date", descending: true)
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  if (snapshot.data != null) {
                    var dd = snapshot.data!.docs.where((element) => element['status'] != 'canceled').toList();
                    return ListView(
                      scrollDirection: Axis.vertical,
                      shrinkWrap: false,
                      padding: const EdgeInsets.all(8),
                      children: List.generate(
                          dd.length,
                          (index) => CompletedItem(
                              document: dd[index])),
                    );
                  } else {
                    return Container();
                  }
                } else {
                  return const Center(
                    child: CircularProgressIndicator(),
                  );
                }
              },
            )
          ],
        ),
      ),
    );
  }
}
