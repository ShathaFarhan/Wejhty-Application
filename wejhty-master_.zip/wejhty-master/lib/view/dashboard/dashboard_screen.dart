import 'package:flutter/material.dart';
import 'package:wejhty/helper/global_data.dart';
import 'package:wejhty/view/dashboard/account/account_screen.dart';
import 'package:wejhty/view/dashboard/bus/bus_screen.dart';
import 'calender/calender_screen.dart';
import 'home/home_screen.dart';

class DashboardScreen extends StatefulWidget {
  static const String routeName = '/dashboardScreen';

  const DashboardScreen({Key? key}) : super(key: key);

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int pageIndex = 0;

  late List<Widget> list;

  @override
  void initState() {
    list = [const HomeScreen(), const CalenderScreen(), const BusScreen(), AccountScreen(onChange: onChangeTab,)];
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: list[pageIndex],
      bottomNavigationBar: buildMyNavBar(context),
    );
  }

  onChangeTab(int inde){
    setState(() {
      pageIndex = inde;
    });
  }

  Widget buildMyNavBar(BuildContext context) {
    return Container(
      height: 60,
      decoration: BoxDecoration(
        color: cs.onPrimary,
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(20),
          topRight: Radius.circular(20),
        ),
        boxShadow: [
          BoxShadow(color: cs.onSurface, blurRadius: 3)
        ]
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          IconButton(
            enableFeedback: false,
            onPressed: () {
              setState(() {
                pageIndex = 0;
              });
            },
            icon: Container(
              alignment: Alignment.center,
              padding: const EdgeInsets.all(1),
              decoration: BoxDecoration(
                  color: pageIndex == 0 ? cs.onSurface : Colors.transparent, borderRadius: BorderRadius.circular(8)),
              child: Image.asset('assets/icons/home.png', height: 24),
            ),
          ),
          IconButton(
            enableFeedback: false,
            onPressed: () {
              setState(() {
                pageIndex = 1;
              });
            },
            icon: Container(
              alignment: Alignment.center,
              padding: const EdgeInsets.all(1),
              decoration: BoxDecoration(
                  color: pageIndex == 1 ? cs.onSurface : Colors.transparent, borderRadius: BorderRadius.circular(8)),
              child: Icon(Icons.calendar_month, size: 24, color: cs.onSecondary,),
            ),
          ),
          IconButton(
            enableFeedback: false,
            onPressed: () {
              setState(() {
                pageIndex = 2;
              });
            },
            icon: Container(
              alignment: Alignment.center,
              padding: const EdgeInsets.all(1),
              decoration: BoxDecoration(
                  color: pageIndex == 2 ? cs.onSurface : Colors.transparent, borderRadius: BorderRadius.circular(8)),
              child: Image.asset('assets/icons/bus.png', height: 24),
            ),
          ),
          IconButton(
            enableFeedback: false,
            onPressed: () {
              setState(() {
                pageIndex = 3;
              });
            },
            icon: Container(
              alignment: Alignment.center,
              padding: const EdgeInsets.all(1),
              decoration: BoxDecoration(
                  color: pageIndex == 3 ? cs.onSurface : Colors.transparent, borderRadius: BorderRadius.circular(8)),
              child: Image.asset('assets/icons/account.png', height: 24),
            ),
          ),
        ],
      ),
    );
  }
}
