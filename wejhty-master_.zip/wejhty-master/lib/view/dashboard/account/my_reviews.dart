import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';

import '../../../helper/global_data.dart';

class MyReviews extends StatelessWidget {
  const MyReviews({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cs.primary,
      appBar: AppBar(
        backgroundColor: cs.primary,
        elevation: 1,
        title: const Text("My Reviews"),
      ),
      body: StreamBuilder<QuerySnapshot>(
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            if (snapshot.data != null) {
              return ListView.builder(
                padding: const EdgeInsets.all(8),
                itemBuilder: (context, index) =>
                    StreamBuilder<DocumentSnapshot>(
                  builder: (context, ss) {
                    if (ss.hasData) {
                      if (ss.data != null) {
                        return getCard(ss.data!, snapshot.data!.docs[index]);
                      }
                      return Container();
                    } else {
                      return Container();
                    }
                  },
                  stream: FirebaseFirestore.instance
                      .collection("event")
                      .doc(snapshot.data!.docs[index]['eventId'])
                      .snapshots(),
                ),
                itemCount: snapshot.data!.docs.length,
              );
            }
            return Container();
          } else {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }
        },
        stream: FirebaseFirestore.instance.collection("reviews").snapshots(),
      ),
    );
  }

  getCard(DocumentSnapshot documentSnapshot, DocumentSnapshot review) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      color: cs.onPrimary,
      elevation: 5,
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.network(
                    documentSnapshot['Thumbnail'],
                    width: size.width * 0.3,
                    height: 100,
                    fit: BoxFit.cover,
                  ),
                ),
                const SizedBox(
                  width: 10,
                ),
                Expanded(
                    child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      child: Text(documentSnapshot['eventname'],
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              color: cs.secondary,
                              fontSize: 20,
                              fontWeight: FontWeight.w600,
                              letterSpacing: 1.3)),
                    ),
                    RatingBar.builder(
                      initialRating: review['rating'],
                      minRating: 1,
                      direction: Axis.horizontal,
                      allowHalfRating: true,
                      itemCount: 5,
                      itemSize: 28,
                      itemPadding: const EdgeInsets.symmetric(horizontal: 2.0),
                      itemBuilder: (context, _) => Icon(
                        Icons.star,
                        color: cs.secondary,
                      ),
                      ignoreGestures: true,
                      onRatingUpdate: (rating) {},
                    ),
                    const SizedBox(height: 5,),
                    Text(
                        "Review On: ${GlobalData.normalFormat.format(review['created_at'].toDate())}", style: TextStyle(
                      color: cs.secondaryContainer, fontSize: 16
                    ),)
                  ],
                ))
              ],
            ),
            const SizedBox(
              height: 10,
            ),
            Text(review['review'])
          ],
        ),
      ),
    );
  }
}
