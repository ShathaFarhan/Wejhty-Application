import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:moment_dart/moment_dart.dart';
import 'package:wejhty/main.dart';
import 'package:wejhty/services/auth_service.dart';
import 'package:wejhty/view/dashboard/account/about_screen.dart';
import 'package:wejhty/view/dashboard/account/my_reviews.dart';
import 'package:wejhty/view/dashboard/calender/bookedEvents/booked_events.dart';

import '../../../helper/global_data.dart';
import '../../../routes/page_route.dart';

class AccountScreen extends StatefulWidget {
  final Function onChange;
  const AccountScreen({Key? key, required this.onChange}) : super(key: key);

  @override
  State<AccountScreen> createState() => _AccountScreenState();
}

class _AccountScreenState extends State<AccountScreen> {
  late Future future;

  @override
  void initState() {
    // TODO: implement initState
    future = AuthService().getCurrentUser();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          color: cs.primary,
          child: Column(
            children: [
              Expanded(
                flex: 1,
                child: Container(),
              ),
              Expanded(
                flex: 1,
                child: Container(
                  decoration: BoxDecoration(
                      color: cs.secondary,
                      borderRadius: BorderRadius.vertical(
                          top: Radius.circular(size.width * 0.2))),
                ),
              )
            ],
          ),
        ),
        Scaffold(
          backgroundColor: Colors.transparent,
          resizeToAvoidBottomInset: true,
          appBar: AppBar(
            backgroundColor: cs.primary,
            elevation: 0,
            actions: [
              CupertinoButton(
                  child: Row(
                    children: [
                      Text(
                        "Log Out",
                        style: TextStyle(
                            color: cs.secondary,
                            fontWeight: FontWeight.w400,
                            fontSize: 14),
                      ),
                      const SizedBox(
                        width: 5,
                      ),
                      RotatedBox(
                        quarterTurns: 3,
                        child: Icon(
                          CupertinoIcons.power,
                          size: 18,
                          color: cs.secondary,
                        ),
                      )
                    ],
                  ),
                  onPressed: () {
                    logoutWarning(context);
                  }),
            ],
          ),
          body: SafeArea(
            child: FutureBuilder(
              builder: (context, snapshot) => snapshot.hasData
                  ? ListView(
                      padding: const EdgeInsets.all(24),
                      children: [
                        if (snapshot.data != null) getAccountCard(context),
                        getSection()
                      ],
                    )
                  : ListView(
                      padding: const EdgeInsets.all(24),
                      children: [
                        FirebaseAuth.instance.currentUser!.isAnonymous
                            ? getAnonymousAccountCard()
                            : Container(),
                        getSection()
                      ],
                    ),
              future: future,
            ),
          ),
        )
      ],
    );
  }

  getAccountCard(context) {
    return StreamBuilder(
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          DocumentSnapshot data = snapshot.data!;
          return Card(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Row(
                children: [
                  Stack(
                    alignment: Alignment.bottomRight,
                    children: [
                      CircleAvatar(
                        radius: 40,
                        backgroundColor: cs.onSurface,
                        backgroundImage: NetworkImage(data['avatar']),
                      ),
                      CupertinoButton(
                        onPressed: () {
                          pickImage();
                        },
                        padding: const EdgeInsets.all(2),
                        minSize: 20,
                        color: cs.primary,
                        borderRadius: BorderRadius.circular(5),
                        child: const Icon(
                          Icons.edit,
                          size: 20,
                        ),
                      )
                    ],
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                  Expanded(
                      child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                              child: Text(
                            data['name'],
                            style: TextStyle(
                                color: cs.primary,
                                fontWeight: FontWeight.w600,
                                fontSize: 18),
                          )),
                          CupertinoButton(
                            onPressed: () {
                              Navigator.pushNamed(
                                      context, PageRoutes.profileUpdate)
                                  .then((value) => refresh());
                            },
                            padding: const EdgeInsets.symmetric(
                                horizontal: 5, vertical: 0),
                            minSize: 24,
                            child: Row(
                              children: [
                                Icon(
                                  Icons.edit,
                                  size: 16,
                                  color: cs.primary,
                                ),
                                const SizedBox(
                                  width: 5,
                                ),
                                Text(
                                  "Edit",
                                  style: TextStyle(
                                      color: cs.primary,
                                      fontWeight: FontWeight.w400,
                                      fontSize: 14),
                                ),
                              ],
                            ),
                          )
                        ],
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      Text(
                        "Since ${Moment.parse(data['created_at']).toLocal().LL}",
                        style: TextStyle(
                            color: cs.secondaryContainer,
                            fontWeight: FontWeight.w400,
                            fontSize: 14),
                      )
                    ],
                  )),
                ],
              ),
            ),
          );
        } else {
          return Container();
        }
      },
      stream: FirebaseFirestore.instance
          .collection('users')
          .doc(FirebaseAuth.instance.currentUser!.uid)
          .snapshots(),
    );
  }

  Future<File?> pickImage() async {
    try {
      final picker = ImagePicker();
      final pickedFile = await picker.pickImage(source: ImageSource.gallery);
      if (pickedFile != null) {
        File file = File(pickedFile.path);
        AuthService().uploadProfileImage(file);
        refresh();
        return file;
      }
      return null;
    } catch (e) {
      logger.e('Failed to pick image: $e');
      return null;
    }
  }

  refresh() {
    future = AuthService().getCurrentUser();
  }

  getAnonymousAccountCard() {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Row(
          children: [
            CircleAvatar(
              radius: 40,
              backgroundColor: cs.onSurface,
              backgroundImage: const NetworkImage(
                  'https://firebasestorage.googleapis.com/v0/b/wejhty-app.appspot.com/o/user-avatar.png?alt=media&token=5c7b4808-d566-4f96-9d60-f67e8a03e53c'),
            ),
            const SizedBox(
              width: 10,
            ),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                          child: Text(
                        "Guest User",
                        style: TextStyle(
                            color: cs.primary,
                            fontWeight: FontWeight.w600,
                            fontSize: 18),
                      )),
                      CupertinoButton(
                        onPressed: () {},
                        padding: const EdgeInsets.symmetric(
                            horizontal: 5, vertical: 0),
                        minSize: 24,
                        child: Row(
                          children: [
                            Icon(
                              Icons.edit,
                              size: 16,
                              color: cs.primary,
                            ),
                            const SizedBox(
                              width: 5,
                            ),
                            Text(
                              "Register",
                              style: TextStyle(
                                  color: cs.primary,
                                  fontWeight: FontWeight.w400,
                                  fontSize: 14),
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  Text(
                    "This is guest user, register to convert into real account.",
                    style: TextStyle(
                        color: cs.secondaryContainer,
                        fontWeight: FontWeight.w400,
                        fontSize: 14),
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  getSection() {
    return Column(
      children: [
        const SizedBox(
          height: 16,
        ),
        Card(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Row(
              children: [
                Expanded(
                    child: CupertinoButton(
                  padding: const EdgeInsets.all(0),
                  onPressed: () {
                    widget.onChange(1);
                  },
                  child: Column(
                    children: [
                      const Icon(Icons.calendar_month_outlined),
                      const SizedBox(
                        height: 5,
                      ),
                      Text(
                        "Event Calender",
                        style: TextStyle(
                            fontSize: 14,
                            color: cs.secondaryContainer,
                            fontWeight: FontWeight.w400),
                      )
                    ],
                  ),
                )),
                Expanded(
                  child: CupertinoButton(
                    padding: const EdgeInsets.all(0),
                    onPressed: () {},
                    child: Column(
                      children: [
                        const Icon(CupertinoIcons.location_solid),
                        const SizedBox(
                          height: 5,
                        ),
                        Text(
                          "Location",
                          style: TextStyle(
                              fontSize: 14,
                              color: cs.secondaryContainer,
                              fontWeight: FontWeight.w400),
                        )
                      ],
                    ),
                  ),
                ),
                Expanded(
                    child: CupertinoButton(
                  padding: const EdgeInsets.all(0),
                  onPressed: () {},
                  child: Column(
                    children: [
                      const Icon(Icons.favorite_border_rounded),
                      const SizedBox(
                        height: 5,
                      ),
                      Text(
                        "Favorites",
                        style: TextStyle(
                            fontSize: 14,
                            color: cs.secondaryContainer,
                            fontWeight: FontWeight.w400),
                      )
                    ],
                  ),
                ))
              ],
            ),
          ),
        ),
        const SizedBox(
          height: 16,
        ),
        Row(
          children: [
            Expanded(
                child: Card(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
              child: CupertinoButton(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => const MyReviews(),));
                },
                child: Row(
                  children: [
                    Expanded(
                        child: Text(
                      "My Reviews",
                      style: TextStyle(
                          fontWeight: FontWeight.w600,
                          color: cs.primary,
                          fontSize: 16),
                    )),
                    const Icon(CupertinoIcons.right_chevron)
                  ],
                ),
              ),
            ))
          ],
        ),
        const SizedBox(
          height: 16,
        ),
        Row(
          children: [
            Expanded(
                child: Card(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
              child: CupertinoButton(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => const BookedEvents(),));
                },
                child: Row(
                  children: [
                    Expanded(
                        child: Text(
                      "My Bookings",
                      style: TextStyle(
                          fontWeight: FontWeight.w600,
                          color: cs.primary,
                          fontSize: 16),
                    )),
                    const Icon(CupertinoIcons.right_chevron)
                  ],
                ),
              ),
            ))
          ],
        ),
        const SizedBox(
          height: 16,
        ),
        Row(
          children: [
            Expanded(
                child: Card(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
              child: CupertinoButton(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => const AboutScreen(),));
                },
                child: Row(
                  children: [
                    Expanded(
                        child: Text(
                      "About Us",
                      style: TextStyle(
                          fontWeight: FontWeight.w600,
                          color: cs.primary,
                          fontSize: 16),
                    )),
                    const Icon(CupertinoIcons.right_chevron)
                  ],
                ),
              ),
            ))
          ],
        )
      ],
    );
  }

  logoutWarning(context) {
    showCupertinoDialog(
        context: context,
        builder: (context) => CupertinoAlertDialog(
              title: Text(
                "Warning",
                style: TextStyle(color: cs.error),
              ),
              content: const Text("Do you really want to logout?"),
              actions: [
                CupertinoButton(
                    child: Text("Logout", style: TextStyle(color: cs.error)),
                    onPressed: () {
                      FirebaseAuth.instance.signOut();
                      Navigator.pushNamedAndRemoveUntil(
                          context, PageRoutes.auth, (route) => false);
                    }),
                CupertinoButton(
                    child: const Text("Cancel"),
                    onPressed: () {
                      Navigator.of(context).pop();
                    }),
              ],
            ),
        barrierDismissible: true);
  }
}
