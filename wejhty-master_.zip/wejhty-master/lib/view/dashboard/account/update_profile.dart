import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dropdown_textfield/dropdown_textfield.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:map_location_picker/map_location_picker.dart';
import 'package:moment_dart/moment_dart.dart';
import 'package:wejhty/main.dart';
import 'package:wejhty/services/auth_service.dart';
import 'package:wejhty/view/dashboard/account/map_location_screen.dart';

import '../../../helper/global_data.dart';
import '../../../routes/page_route.dart';

class ProfileUpdateScreen extends StatefulWidget {
  static const String routeName = '/profileUpdateScreen';
  const ProfileUpdateScreen({Key? key}) : super(key: key);

  @override
  State<ProfileUpdateScreen> createState() => _ProfileUpdateScreenState();
}

class _ProfileUpdateScreenState extends State<ProfileUpdateScreen> {
  static final TextEditingController _emailController = TextEditingController();
  static final TextEditingController _phoneController = TextEditingController();
  static final TextEditingController _nameController = TextEditingController();
  static final TextEditingController _locationController =
      TextEditingController();
  static final SingleValueDropDownController _genderController =
      SingleValueDropDownController();
  Map? location = {"lat": 24.196312, "long": 45.853587};
  String image =
      'https://firebasestorage.googleapis.com/v0/b/wejhty-app.appspot.com/o/user-avatar.png?alt=media&token=5c7b4808-d566-4f96-9d60-f67e8a03e53c';

  late Future future;

  @override
  void initState() {
    clearData();
    future = initializeData();
    // ignore: todo
    // TODO: implement initState
    super.initState();
  }

  clearData() {
    _nameController.clear();
    _emailController.clear();
    _phoneController.clear();
    _locationController.clear();
    _genderController.clearDropDown();
  }

  _update(context) {
    String phone = _phoneController.text.trim();
    String name = _nameController.text.trim();
    String? gender = _genderController.dropDownValue?.value;
    String address = _locationController.text.trim();
    if (!GlobalData.phoneRegExp.hasMatch(phone.trim()) ||
        name.isEmpty ||
        address.isEmpty ||
        gender == null ||
        location == null) {
      EasyLoading.showToast('All fields are mandatory.',
          duration: const Duration(seconds: 1));
      return;
    }
    FocusScope.of(context).unfocus();
    var data = {
      "name": _nameController.text,
      "phone": _phoneController.text,
      "gender": _genderController.dropDownValue!.value,
      "address": _locationController.text,
      "location": location
    };
    AuthService().updateUserData(data);
  }

  initializeData() async {
    DocumentSnapshot<Map<String, dynamic>>? documentSnapshot =
        await AuthService().getCurrentUser();
    if (documentSnapshot != null) {
      var data = documentSnapshot.data()!;
      if (data.containsKey('name')) {
        _nameController.text = data['name'] ?? "";
      }
      if (data.containsKey('avatar')) {
        image = data['avatar'] ??
            'https://firebasestorage.googleapis.com/v0/b/wejhty-app.appspot.com/o/user-avatar.png?alt=media&token=5c7b4808-d566-4f96-9d60-f67e8a03e53c';
      }
      if (data.containsKey('email')) {
        _emailController.text = data['email'] ?? "";
      }
      if (data.containsKey('phone')) {
        _phoneController.text = data['phone'] ?? "";
      }
      if (data.containsKey('gender')) {
        _genderController.dropDownValue = DropDownValueModel(
            name: data['gender'] ?? "", value: data['gender'] ?? "");
      }
      if (data.containsKey('address')) {
        _locationController.text = data['address'] ?? "";
      }
      if (data.containsKey('location')) {
        location = data['location'] ?? "";
      }
    }
    return true;
  }

  onLocationSelect(Location? latLng, String? address) {
    logger.d("$location $address");
    if (latLng != null && address != null) {
      _locationController.text = address;
      location = {"lat": latLng.lat, "long": latLng.lng};
      logger.d(location);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          color: cs.primary,
          child: Column(
            children: [
              Expanded(
                flex: 1,
                child: Padding(
                  padding: const EdgeInsets.only(top: 160),
                  child: Container(
                    decoration: BoxDecoration(
                        color: cs.secondary,
                        borderRadius: BorderRadius.vertical(
                            top: Radius.circular(size.width * 0.4))),
                  ),
                ),
              )
            ],
          ),
        ),
        Scaffold(
          backgroundColor: Colors.transparent,
          resizeToAvoidBottomInset: true,
          appBar: AppBar(backgroundColor: cs.primary, elevation: 0),
          body: SafeArea(
            child: FutureBuilder(
              builder: (context, snapshot) => ListView(
                padding: const EdgeInsets.only(top: 50, left: 24, right: 24),
                children: [
                  CircleAvatar(
                    radius: 50,
                    backgroundColor: cs.onPrimary,
                    child: CircleAvatar(
                      radius: 44,
                      backgroundColor: cs.onSurface,
                      backgroundImage: NetworkImage(image),
                    ),
                  ),
                  Card(
                    elevation: 8,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(24)),
                    color: cs.onPrimary,
                    margin: const EdgeInsets.only(top: 24),
                    child: Padding(
                      padding: EdgeInsets.symmetric(
                          vertical: size.height * 0.05, horizontal: 16),
                      child: Column(
                        children: [
                          SizedBox(
                            height: 40,
                            child: CupertinoTextField(
                              placeholder: "Full Name",
                              controller: _nameController,
                              keyboardType: TextInputType.name,
                              textInputAction: TextInputAction.next,
                              decoration: BoxDecoration(
                                  border:
                                      Border.all(color: cs.primary, width: 2),
                                  borderRadius: BorderRadius.circular(20)),
                            ),
                          ),
                          const SizedBox(
                            height: 20,
                          ),
                          SizedBox(
                            height: 40,
                            child: CupertinoTextField(
                              placeholder: "Email Address",
                              enabled: false,
                              controller: _emailController,
                              keyboardType: TextInputType.emailAddress,
                              textInputAction: TextInputAction.next,
                              style: TextStyle(
                                  color:
                                      cs.secondaryContainer.withOpacity(0.5)),
                              decoration: BoxDecoration(
                                  border:
                                      Border.all(color: cs.onSurface, width: 2),
                                  borderRadius: BorderRadius.circular(20)),
                            ),
                          ),
                          const SizedBox(
                            height: 20,
                          ),
                          SizedBox(
                            height: 40,
                            child: CupertinoTextField(
                              placeholder: "Phone",
                              controller: _phoneController,
                              maxLength: 10,
                              keyboardType: TextInputType.phone,
                              textInputAction: TextInputAction.next,
                              decoration: BoxDecoration(
                                  border:
                                      Border.all(color: cs.primary, width: 2),
                                  borderRadius: BorderRadius.circular(20)),
                            ),
                          ),
                          SizedBox(
                            height: size.height * 0.03,
                          ),
                          SizedBox(
                            height: 40,
                            child: DropDownTextField(
                              controller: _genderController,
                              clearOption: false,
                              listTextStyle: TextStyle(
                                  color: cs.secondaryContainer,
                                  fontWeight: FontWeight.w500,
                                  fontSize: 16),
                              textFieldDecoration: InputDecoration(
                                border: OutlineInputBorder(
                                    borderSide:
                                        BorderSide(width: 2, color: cs.primary),
                                    borderRadius: BorderRadius.circular(20)),
                                fillColor: cs.secondaryContainer,
                                hintText: "Gender",
                                hintStyle: TextStyle(
                                    color:
                                        cs.secondaryContainer.withOpacity(0.3),
                                    fontWeight: FontWeight.w500,
                                    fontSize: 14),
                                enabledBorder: OutlineInputBorder(
                                    borderSide:
                                        BorderSide(width: 2, color: cs.primary),
                                    borderRadius: BorderRadius.circular(20)),
                                labelStyle: TextStyle(
                                    color:
                                        cs.secondaryContainer.withOpacity(0.3),
                                    fontWeight: FontWeight.w500,
                                    fontSize: 14),
                              ),
                              enableSearch: false,
                              dropDownList: const [
                                DropDownValueModel(name: 'Male', value: "Male"),
                                DropDownValueModel(
                                    name: 'Female', value: "Female"),
                              ],
                              onChanged: (val) {},
                            ),
                          ),
                          const SizedBox(
                            height: 20,
                          ),
                          SizedBox(
                            height: 40,
                            child: CupertinoTextField(
                              placeholder: "Location",
                              controller: _locationController,
                              readOnly: true,
                              onTap: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => MapLocationScreen(
                                          function: onLocationSelect,
                                          location: location),
                                    ));
                              },
                              suffix: Padding(
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 5),
                                child: Icon(
                                  CupertinoIcons.location_solid,
                                  size: 20,
                                  color: cs.primary,
                                ),
                              ),
                              keyboardType: TextInputType.phone,
                              textInputAction: TextInputAction.next,
                              decoration: BoxDecoration(
                                  border:
                                      Border.all(color: cs.primary, width: 2),
                                  borderRadius: BorderRadius.circular(20)),
                            ),
                          ),
                          SizedBox(
                            height: size.height * 0.03,
                          ),
                          SizedBox(
                              width: size.width * 0.5,
                              child: CupertinoButton(
                                  onPressed: () {
                                    _update(context);
                                  },
                                  padding: const EdgeInsets.all(5),
                                  color: cs.primary,
                                  child: const Text("UPDATE",
                                      style: TextStyle(
                                        letterSpacing: 1.2,
                                      )))),
                        ],
                      ),
                    ),
                  )
                ],
              ),
              future: future,
            ),
          ),
        )
      ],
    );
  }

  getAccountCard(DocumentSnapshot data) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Row(
          children: [
            CircleAvatar(
              radius: 40,
              backgroundColor: cs.onSurface,
              backgroundImage: NetworkImage(data['avatar']),
            ),
            const SizedBox(
              width: 10,
            ),
            Expanded(
                child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                        child: Text(
                      data['name'],
                      style: TextStyle(
                          color: cs.primary,
                          fontWeight: FontWeight.w600,
                          fontSize: 18),
                    )),
                    CupertinoButton(
                      onPressed: () {},
                      padding: const EdgeInsets.symmetric(
                          horizontal: 5, vertical: 0),
                      minSize: 24,
                      child: Row(
                        children: [
                          Icon(
                            Icons.edit,
                            size: 16,
                            color: cs.primary,
                          ),
                          const SizedBox(
                            width: 5,
                          ),
                          Text(
                            "Edit",
                            style: TextStyle(
                                color: cs.primary,
                                fontWeight: FontWeight.w400,
                                fontSize: 14),
                          ),
                        ],
                      ),
                    )
                  ],
                ),
                const SizedBox(
                  height: 5,
                ),
                Text(
                  "Since ${Moment.parse(data['created_at']).toLocal().LL}",
                  style: TextStyle(
                      color: cs.secondaryContainer,
                      fontWeight: FontWeight.w400,
                      fontSize: 14),
                )
              ],
            )),
          ],
        ),
      ),
    );
  }

  getAnonymousAccountCard() {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Row(
          children: [
            CircleAvatar(
              radius: 40,
              backgroundColor: cs.onSurface,
              backgroundImage: const NetworkImage(
                  'https://firebasestorage.googleapis.com/v0/b/wejhty-app.appspot.com/o/user-avatar.png?alt=media&token=5c7b4808-d566-4f96-9d60-f67e8a03e53c'),
            ),
            const SizedBox(
              width: 10,
            ),
            Expanded(
                child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                        child: Text(
                      "Guest User",
                      style: TextStyle(
                          color: cs.primary,
                          fontWeight: FontWeight.w600,
                          fontSize: 18),
                    )),
                    CupertinoButton(
                      onPressed: () {},
                      padding: const EdgeInsets.symmetric(
                          horizontal: 5, vertical: 0),
                      minSize: 24,
                      child: Row(
                        children: [
                          Icon(
                            Icons.edit,
                            size: 16,
                            color: cs.primary,
                          ),
                          const SizedBox(
                            width: 5,
                          ),
                          Text(
                            "Register",
                            style: TextStyle(
                                color: cs.primary,
                                fontWeight: FontWeight.w400,
                                fontSize: 14),
                          ),
                        ],
                      ),
                    )
                  ],
                ),
                const SizedBox(
                  height: 5,
                ),
                Text(
                  "This is guest user, register to convert into real account.",
                  style: TextStyle(
                      color: cs.secondaryContainer,
                      fontWeight: FontWeight.w400,
                      fontSize: 14),
                )
              ],
            )),
          ],
        ),
      ),
    );
  }

  logoutWarning(context) {
    showCupertinoDialog(
        context: context,
        builder: (context) => CupertinoAlertDialog(
              title: Text(
                "Warning",
                style: TextStyle(color: cs.error),
              ),
              content: const Text("Do you really want to logout?"),
              actions: [
                CupertinoButton(
                    child: Text("Logout", style: TextStyle(color: cs.error)),
                    onPressed: () {
                      FirebaseAuth.instance.signOut();
                      Navigator.pushNamedAndRemoveUntil(
                          context, PageRoutes.auth, (route) => false);
                    }),
                CupertinoButton(
                    child: const Text("Cancel"),
                    onPressed: () {
                      Navigator.of(context).pop();
                    }),
              ],
            ),
        barrierDismissible: true);
  }
}
