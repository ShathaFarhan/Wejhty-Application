import 'package:flutter/material.dart';

import '../../../helper/global_data.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cs.primary,
      body: Stack(
        children: [
          Container(
            color: cs.primary,
            child: Column(
              children: [
                Expanded(
                  flex: 1,
                  child: Container(),
                ),
                Expanded(
                  flex: 1,
                  child: Container(
                    decoration: BoxDecoration(
                        color: cs.secondary,
                        borderRadius: BorderRadius.vertical(
                            top: Radius.circular(size.width * 0.2))),
                  ),
                )
              ],
            ),
          ),
          Scaffold(
            backgroundColor: Colors.transparent,
            resizeToAvoidBottomInset: true,
            appBar: AppBar(
              backgroundColor: cs.primary,
              elevation: 0,
            ),
            body: SafeArea(
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        "About Us",
                        style: TextStyle(
                            color: cs.secondary,
                            fontSize: 32,
                            fontWeight: FontWeight.w600),
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      Card(
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20)),
                        child: Padding(
                          padding: const EdgeInsets.all(16.0),
                          child: Column(
                            children: [
                              Text(
                                "The idea of our project is to design an extensive application that collects data of the main cities in Saudi Arabia with useful features that support easy access to the desired activities of the user's location",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    color: cs.onSecondary,
                                    fontWeight: FontWeight.w400,
                                    fontSize: 18),
                              ),
                              const SizedBox(
                                height: 16,
                              ),
                              Text(
                                "Creators",
                                style: TextStyle(
                                    color: cs.secondaryContainer,
                                    fontSize: 24,
                                    fontWeight: FontWeight.w600),
                              ),
                              getBottom()
                            ],
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }

  getBottom() {
    return Padding(
      padding: const EdgeInsets.all(24.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Column(
            children: [
              const Icon(Icons.account_box_outlined, size: 50,),
              const SizedBox(
                height: 5,
              ),
              Text(
                "Norah",
                style: TextStyle(
                    fontSize: 14,
                    color: cs.secondaryContainer,
                    fontWeight: FontWeight.w400),
              )
            ],
          ),
          Column(
            children: [
              const Icon(Icons.account_box_outlined, size: 50,),
              const SizedBox(
                height: 5,
              ),
              Text(
                "Nuha",
                style: TextStyle(
                    fontSize: 14,
                    color: cs.secondaryContainer,
                    fontWeight: FontWeight.w400),
              )
            ],
          ),
          Column(
            children: [
              const Icon(Icons.account_box_outlined, size: 50,),
              const SizedBox(
                height: 5,
              ),
              Text(
                "Rozana",
                style: TextStyle(
                    fontSize: 14,
                    color: cs.secondaryContainer,
                    fontWeight: FontWeight.w400),
              )
            ],
          ),
          Column(
            children: [
              const Icon(Icons.account_box_outlined, size: 50,),
              const SizedBox(
                height: 5,
              ),
              Text(
                "Shatha",
                style: TextStyle(
                    fontSize: 14,
                    color: cs.secondaryContainer,
                    fontWeight: FontWeight.w400),
              )
            ],
          ),
        ],
      ),
    );
  }
}
