import 'package:flutter/material.dart';
import 'package:map_location_picker/map_location_picker.dart';
import 'package:wejhty/helper/map_api.dart';
import 'package:wejhty/main.dart';

import '../../../helper/global_data.dart';

class MapLocationScreen extends StatefulWidget {
  static const String routeName = '/mapLocationScreen';
  final Function function;
  final Map? location;

  const MapLocationScreen({Key? key, this.location, required this.function})
      : super(key: key);

  @override
  State<MapLocationScreen> createState() => _MapLocationScreenState();
}

class _MapLocationScreenState extends State<MapLocationScreen> {
  String address = "null";
  String autocompletePlace = "null";
  Prediction? initialValue;
  LatLng latLng = const LatLng(24.1662448, 40.5801496);

  String? addr;
  Location? location;

  @override
  void initState() {
    logger.d("Location ${widget.location}");
    if (widget.location != null) {
      latLng = LatLng(widget.location!['lat'], widget.location!['long']);
    }
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: cs.primary,
        title: Text(
          "Select Location",
          style: TextStyle(color: cs.onPrimary, fontSize: 16),
        ),
      ),
      body: MapLocationPicker(
        apiKey: APIKeys.iosApiKey,
        canPopOnNextButtonTaped: true,
        currentLatLng: latLng,
        showBackButton: false,
        showMoreOptions: false,
        bottomCardColor: cs.onSurface,
        topCardColor: cs.onPrimary,
        onNext: (GeocodingResult? result) {
          try{
            if (result != null) {
              logger.d("On Select ${result.formattedAddress}");
              // widget.function(result.geometry.location, result.formattedAddress);
              setState(() {
                address = result.formattedAddress ?? "";
                addr = result.formattedAddress ?? "";
                location = result.geometry.location;
              });
            }
            widget.function(location, addr);
          }catch(e){
            logger.e(e);
          }
        },
        onSuggestionSelected: (PlacesDetailsResponse? result) {
          if (result != null) {
            logger.d("Address ${result.result.formattedAddress}");
            setState(() {
              autocompletePlace = result.result.formattedAddress ?? "";
              addr = result.result.formattedAddress;
              location = result.result.geometry!.location;
            });
          }
        },
      ),
    );
  }
}
