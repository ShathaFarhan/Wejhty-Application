import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../../../helper/global_data.dart';
import 'components/event_card.dart';
import 'components/event_heading.dart';

class AllEventScreen extends StatelessWidget {
  final String type;
  const AllEventScreen({Key? key, required this.type}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cs.primary,
      body: SizedBox(
        width: size.width,
        child: ListView(
          shrinkWrap: false,
          padding: const EdgeInsets.symmetric(vertical: 16),
          children: [
            /// Heading
            Row(
              children: [
                IconButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    icon: Icon(
                      CupertinoIcons.left_chevron,
                      color: cs.secondary,
                    )),
                Expanded(
                    child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "$type Events",
                        style: TextStyle(
                            color: cs.secondary,
                            fontSize: 24,
                            fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                )),
                IconButton(
                    onPressed: () {},
                    icon: Icon(
                      CupertinoIcons.bell,
                      color: cs.secondary,
                    ))
              ],
            ),

            StreamBuilder(
              stream: type == "All" ? FirebaseFirestore.instance.collection("event").snapshots() : FirebaseFirestore.instance.collection("event").where(type == "Featured" ? "Is_featured" : type == "Popular" ? "Is_popular" : "Type", isEqualTo: type == "Featured" || type == "Popular" ? true : type).snapshots(),
              builder: (context, snapshot) {
                if(snapshot.hasData){
                  if(snapshot.data != null){
                    return Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Wrap(
                        runSpacing: 8,
                        alignment: WrapAlignment.start,
                        crossAxisAlignment: WrapCrossAlignment.start,
                        spacing: 8,
                        children: List.generate(
                            snapshot.data!.docs.length, (index) => EventCard(documentSnapshot: snapshot.data!.docs[index],)),
                      ),
                    );
                  }else{
                    return Container();
                  }
                }else{
                  return Container();
                }
              },
            )

            /// Riydah
            // Padding(
            //   padding: const EdgeInsets.all(8.0),
            //   child: EventHeading(
            //     heading: "Riydah",
            //     onPressed: () {},
            //     isTrailingEnabled: false,
            //   ),
            // ),
            // SizedBox(
            //   width: size.width,
            //   height: 170,
            //   child: ListView(
            //     scrollDirection: Axis.horizontal,
            //     shrinkWrap: true,
            //     padding:
            //         const EdgeInsets.symmetric(horizontal: 16, vertical: 0),
            //     children: List.generate(5, (index) => const EventCard()),
            //   ),
            // ),

            // const SizedBox(
            //   height: 16,
            // ),

            /// Jeddah
            // Padding(
            //   padding: const EdgeInsets.all(8.0),
            //   child: EventHeading(
            //     heading: "Jeddah",
            //     onPressed: () {},
            //     isTrailingEnabled: false,
            //   ),
            // ),
            // SizedBox(
            //   width: size.width,
            //   height: 170,
            //   child: ListView(
            //     scrollDirection: Axis.horizontal,
            //     shrinkWrap: true,
            //     padding:
            //         const EdgeInsets.symmetric(horizontal: 16, vertical: 0),
            //     children: List.generate(5, (index) => const EventCard()),
            //   ),
            // ),

            // const SizedBox(
            //   height: 16,
            // ),

            /// Khobar
            // Padding(
            //   padding: const EdgeInsets.all(8.0),
            //   child: EventHeading(
            //     heading: "Khobar",
            //     onPressed: () {},
            //     isTrailingEnabled: false,
            //   ),
            // ),
            // SizedBox(
            //   width: size.width,
            //   height: 170,
            //   child: ListView(
            //     scrollDirection: Axis.horizontal,
            //     shrinkWrap: true,
            //     padding:
            //     const EdgeInsets.symmetric(horizontal: 16, vertical: 0),
            //     children: List.generate(5, (index) => const EventCard()),
            //   ),
            // ),
          ],
        ),
      ),
    );
  }
}
