import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../../../helper/global_data.dart';

class EventHeading extends StatelessWidget {
  final String heading;
  final Function onPressed;
  final bool isTrailingEnabled;
  const EventHeading({Key? key, required this.heading, required this.onPressed, this.isTrailingEnabled = true}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          Expanded(child: Text(heading,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                  color: cs.secondary,
                  fontSize: 24,
                  fontWeight: FontWeight.w500,
                  letterSpacing: 1.3)),),
          if(isTrailingEnabled)
          CupertinoButton(onPressed: (){
            onPressed();
          }, padding: const EdgeInsets.all(5),child: Row(
            children: [
              Text("See All", style: TextStyle(color: cs.secondary),),
              const SizedBox(width: 5,),
              Icon(CupertinoIcons.right_chevron, color: cs.secondary, size: 18,)
            ],
          ),)
        ],
      ),
    );
  }
}
