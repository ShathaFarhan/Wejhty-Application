import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:wejhty/helper/global_data.dart';

import '../detail_screen.dart';

class FeatureCard extends StatelessWidget {
  final DocumentSnapshot documentSnapshot;
  const FeatureCard({Key? key, required this.documentSnapshot}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size.width * 0.7,
      child: CupertinoButton(
        onPressed: (){
          Navigator.push(context, MaterialPageRoute(builder: (context) => DetailScreen(documentSnapshot: documentSnapshot),));
        },
        padding: const EdgeInsets.all(0),
        child: Card(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          color: cs.secondary.withOpacity(0.3),
          elevation: 5,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius:
                    const BorderRadius.vertical(top: Radius.circular(16)),
                child: Image.network(
                  documentSnapshot['Thumbnail'],
                  width: size.width * 0.7,
                  height: size.width * 0.4,
                  fit: BoxFit.cover,
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 10,),
                    RatingBar.builder(
                      initialRating: double.parse(documentSnapshot['Ratings'].toString()),
                      minRating: 1,
                      direction: Axis.horizontal,
                      allowHalfRating: true,
                      itemCount: 5,
                      itemSize: 20,
                      ignoreGestures: true,
                      itemPadding: const EdgeInsets.symmetric(horizontal: 2.0),
                      itemBuilder: (context, _) => Icon(
                        Icons.star,
                        color: cs.secondary,
                      ),
                      onRatingUpdate: (rating) {
                        print(rating);
                      },
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      child: Text(documentSnapshot['eventname'],
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              color: cs.secondary,
                              fontSize: 24,
                              fontWeight: FontWeight.w600,
                              letterSpacing: 1.3)),
                    ),
                    Row(
                      children: [
                        Icon(
                          CupertinoIcons.location_solid,
                          color: cs.onPrimary,
                          size: 18,
                        ),
                        Expanded(
                            child: Text(
                          documentSnapshot['eventcity'],
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              color: cs.onPrimary.withOpacity(0.7),
                              fontSize: 16,
                              fontWeight: FontWeight.w400),
                        ))
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      child: Text(
                        "\$${documentSnapshot['price']}/${documentSnapshot['price_duration']}",
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            color: cs.onPrimary.withOpacity(0.7),
                            fontWeight: FontWeight.w600,
                            fontSize: 24),
                      ),
                    )
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
