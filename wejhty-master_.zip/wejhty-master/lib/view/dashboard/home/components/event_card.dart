import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:wejhty/helper/global_data.dart';
import 'package:wejhty/view/dashboard/home/detail_screen.dart';

class EventCard extends StatelessWidget {
  final DocumentSnapshot documentSnapshot;
  const EventCard({Key? key, required this.documentSnapshot}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      child: CupertinoButton(
        onPressed: (){
          Navigator.push(context, MaterialPageRoute(builder: (context) => DetailScreen(documentSnapshot: documentSnapshot),));
        },
        padding: const EdgeInsets.all(0),
        child: Card(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          color: cs.secondary.withOpacity(0.3),
          elevation: 5,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              ClipRRect(
                borderRadius:
                const BorderRadius.vertical(top: Radius.circular(16)),
                child: Image.network(
                  documentSnapshot['Thumbnail'],
                  width: size.width*0.5 - 24,
                  height: 120,
                  fit: BoxFit.cover,
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: Text(documentSnapshot['eventname'],
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        color: cs.secondary,
                        fontSize: 18,
                        fontWeight: FontWeight.w500,
                        letterSpacing: 1.3)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
