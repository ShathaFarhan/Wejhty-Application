import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:wejhty/helper/global_data.dart';
import 'package:wejhty/view/common/custom_list_tile.dart';
import 'package:wejhty/view/dashboard/home/bookOrder/new_order.dart';

class DetailScreen extends StatefulWidget {
  final DocumentSnapshot documentSnapshot;

  const DetailScreen({Key? key, required this.documentSnapshot})
      : super(key: key);

  @override
  State<DetailScreen> createState() => _DetailScreenState();
}

class _DetailScreenState extends State<DetailScreen>
    with TickerProviderStateMixin {
  static DateTime? _chosenDateTime;
  late TabController tabController;

  // Show the modal that contains the CupertinoDatePicker
  void _showDatePicker(context) {
    // showCupertinoModalPopup is a built-in function of the cupertino library
    showCupertinoModalPopup(
      context: context,
      builder: (_) => Container(
        height: 260,
        color: const Color.fromARGB(255, 255, 255, 255),
        child: Column(
          children: [
            SizedBox(
              height: 260,
              child: CupertinoDatePicker(
                  initialDateTime: DateTime.now().add(const Duration(days: 1)),
                  minimumDate: DateTime.now(),
                  mode: CupertinoDatePickerMode.date,
                  maximumYear: DateTime.now().year + 1,
                  onDateTimeChanged: (val) {
                    setState(() {
                      _chosenDateTime = val;
                    });
                  }),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void initState() {
    _chosenDateTime = null;
    tabController = TabController(length: 2, vsync: this);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cs.primary,
      body: Stack(
        alignment: Alignment.bottomCenter,
        children: [
          ListView(
            padding: const EdgeInsets.only(bottom: 10),
            children: [
              Stack(
                alignment: Alignment.topLeft,
                children: [
                  ClipRRect(
                    borderRadius: const BorderRadius.vertical(
                        bottom: Radius.circular(16)),
                    child: Image.network(
                      widget.documentSnapshot['Thumbnail'],
                      width: size.width,
                      height: size.width * 0.8,
                      fit: BoxFit.cover,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 20),
                    child: Row(
                      children: [
                        IconButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                            icon: Icon(
                              CupertinoIcons.left_chevron,
                              color: cs.secondary,
                            )),
                        const Spacer(),
                        IconButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                            icon: Icon(
                              CupertinoIcons.heart,
                              color: cs.secondary,
                            )),
                      ],
                    ),
                  )
                ],
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(
                      height: 10,
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 0),
                      child: Text(widget.documentSnapshot['eventname'],
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              color: cs.secondary,
                              fontSize: 24,
                              fontWeight: FontWeight.w600,
                              letterSpacing: 1.3)),
                    ),
                    Row(
                      children: [
                        Expanded(
                            child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                RatingBar.builder(
                                  initialRating: double.parse(widget
                                      .documentSnapshot['Ratings']
                                      .toString()),
                                  minRating: 1,
                                  direction: Axis.horizontal,
                                  allowHalfRating: true,
                                  itemCount: 5,
                                  itemSize: 20,
                                  ignoreGestures: true,
                                  itemPadding: const EdgeInsets.symmetric(
                                      horizontal: 2.0, vertical: 5),
                                  itemBuilder: (context, _) => Icon(
                                    Icons.star,
                                    color: cs.secondary,
                                  ),
                                  updateOnDrag: false,
                                  onRatingUpdate: (rating) {},
                                ),
                                StreamBuilder(
                                  builder: (context, snapshot) {
                                    if (snapshot.hasData) {
                                      if (snapshot.data != null) {
                                        return Text(
                                          "(${snapshot.data!.docs.length})",
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: TextStyle(
                                              color: cs.onPrimary.withOpacity(0.7),
                                              fontSize: 16,
                                              fontWeight: FontWeight.w400),
                                        );
                                      }
                                      return Container();
                                    } else {
                                      return const Center(
                                        child: CircularProgressIndicator(),
                                      );
                                    }
                                  },
                                  stream: FirebaseFirestore.instance.collection("reviews").where("eventId", isEqualTo: widget.documentSnapshot.id).snapshots(),
                                ),
                              ],
                            ),
                            Row(
                              children: [
                                Icon(
                                  CupertinoIcons.location_solid,
                                  color: cs.onPrimary,
                                  size: 18,
                                ),
                                Expanded(
                                    child: Text(
                                  "${widget.documentSnapshot['eventcity']}",
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                      color: cs.onPrimary.withOpacity(0.7),
                                      fontSize: 16,
                                      fontWeight: FontWeight.w400),
                                ))
                              ],
                            ),
                          ],
                        )),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            CupertinoButton(
                                child: Icon(
                                  CupertinoIcons.calendar,
                                  color: cs.onPrimary,
                                ),
                                onPressed: () {
                                  _showDatePicker(context);
                                }),
                            if (_chosenDateTime != null)
                              Text(
                                GlobalData.normalFormat
                                    .format(_chosenDateTime!),
                                style: TextStyle(
                                    color: cs.onPrimary,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600),
                              )
                          ],
                        )
                      ],
                    ),
                    const SizedBox(
                      height: 16,
                    ),
                    TabBar(
                      controller: tabController,
                      isScrollable: true,
                      onTap: (index) {
                        setState(() {});
                      },
                      labelColor: cs.secondary,
                      indicatorColor: cs.secondary,
                      tabs: const [
                        Tab(
                          text: "Description",
                        ),
                        Tab(
                          text: "Reviews",
                        )
                      ],
                    ),
                    if (tabController.index == 0)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        child: Text(
                          widget.documentSnapshot['eventdesc'],
                          style: TextStyle(
                              color: cs.onPrimary.withOpacity(0.7),
                              fontSize: 16,
                              fontWeight: FontWeight.w500),
                        ),
                      ),
                    if (tabController.index == 1)
                      StreamBuilder(
                        builder: (context, snapshot) {
                          if (snapshot.hasData) {
                            if (snapshot.data != null) {
                              return ListView.builder(
                                padding: const EdgeInsets.all(8),
                                physics: const NeverScrollableScrollPhysics(),
                                shrinkWrap: true,
                                itemBuilder: (context, index) {
                                  return Padding(
                                    padding: const EdgeInsets.only(bottom: 10),
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Padding(
                                          padding: const EdgeInsets.only(top: 10, right: 10),
                                          child: CircleAvatar(
                                            backgroundColor: cs.onSurface,
                                            radius: 16,
                                            backgroundImage: NetworkImage(GlobalData.defaultUserAvatar),
                                          ),
                                        ),
                                        Expanded(child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            RatingBar.builder(
                                              initialRating: double.parse(snapshot.data!.docs[index]['rating']
                                                  .toString()),
                                              minRating: 1,
                                              direction: Axis.horizontal,
                                              allowHalfRating: true,
                                              itemCount: 5,
                                              itemSize: 20,
                                              ignoreGestures: true,
                                              itemPadding: const EdgeInsets.symmetric(
                                                  horizontal: 2.0, vertical: 5),
                                              itemBuilder: (context, _) => Icon(
                                                Icons.star,
                                                color: cs.secondary,
                                              ),
                                              updateOnDrag: false,
                                              onRatingUpdate: (rating) {},
                                            ),
                                            Padding(
                                              padding: const EdgeInsets.symmetric(vertical: 5),
                                              child: Text(
                                                snapshot.data!.docs[index]['review'],
                                                style: TextStyle(
                                                    color: cs.onPrimary.withOpacity(0.7),
                                                    fontSize: 16,
                                                    fontWeight: FontWeight.w500),
                                              ),
                                            ),
                                          ],
                                        ))
                                      ],
                                    ),
                                  );
                                },
                                itemCount: snapshot.data!.docs.length,
                              );
                            }
                            return Container();
                          } else {
                            return const Center(
                              child: CircularProgressIndicator(),
                            );
                          }
                        },
                        stream: FirebaseFirestore.instance.collection("reviews").where("eventId", isEqualTo: widget.documentSnapshot.id).snapshots(),
                      ),
                    const SizedBox(
                      height: 16,
                    ),
                    Text(
                      "Gallery",
                      style: TextStyle(
                          color: cs.secondary,
                          fontSize: 16,
                          fontWeight: FontWeight.w500),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    SizedBox(
                      width: size.width,
                      height: 80,
                      child: ListView(
                        scrollDirection: Axis.horizontal,
                        shrinkWrap: true,
                        children: List.generate(
                            List.from(widget.documentSnapshot['gallery'])
                                .length,
                            (index) => Padding(
                                  padding:
                                      const EdgeInsets.symmetric(horizontal: 5),
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(10),
                                    child: Image.network(
                                      List.from(widget
                                          .documentSnapshot['gallery'])[index],
                                      width: 120,
                                      height: 80,
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                )),
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        ],
      ),
      bottomNavigationBar: SizedBox(
        height: 60,
        child: Card(
          color: cs.secondary.withOpacity(0.3),
          child: Row(
            children: [
              Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Text(
                      "\$${widget.documentSnapshot['price']}/${widget.documentSnapshot['price_duration']}",
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          color: cs.onPrimary.withOpacity(0.7),
                          fontWeight: FontWeight.w600,
                          fontSize: 18),
                    ),
                  )),
              SizedBox(
                height: 40,
                width: 120,
                child: CupertinoButton(
                  onPressed: () {
                    if (_chosenDateTime != null) {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => NewOrderScreen(
                                documentSnapshot: widget.documentSnapshot,
                                dateTime: _chosenDateTime!),
                          ));
                    } else {
                      EasyLoading.showToast("Select Booking Date",
                          duration: const Duration(seconds: 1));
                    }
                  },
                  color: cs.primary,
                  padding: const EdgeInsets.all(0),
                  child: const Text("Book Event"),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
