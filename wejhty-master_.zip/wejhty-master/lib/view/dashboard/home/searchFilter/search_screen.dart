import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:custom_radio_grouped_button/custom_radio_grouped_button.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:wejhty/helper/global_data.dart';
import 'package:wejhty/main.dart';

import '../components/event_card.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({Key? key}) : super(key: key);

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  TextEditingController textEditingController = TextEditingController();
  List<DocumentSnapshot> docs = [];
  List<String> sortBy = [
    'Best Match',
    'Law Budget',
    'Nearest',
  ];
  List<String> type = [
    'Indoor',
    'Outdoor',
    'Mix',
  ];
  List<String> operational = ['Open', 'Closed'];
  List<String> ratings = ['Below 3', '3-4', '4-5'];
  List<String> includes = [
    'Restaurant',
    'Toilet',
    'Hotel & Homestay',
    'Mall',
    'Minimart',
    'Gas Station',
    'Musholla'
  ];

  List<String> sselectedSortBy = [];
  List<String> sselectedType = [];
  List<String> sselectedOperational = [];
  List<String> sselectedRatings = [];
  List<String> sselectedIncludes = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cs.primary,
      body: ListView(
        shrinkWrap: false,
        padding: const EdgeInsets.symmetric(vertical: 16),
        children: [
          /// Heading
          Row(
            children: [
              IconButton(
                  onPressed: () {
                    FocusScope.of(context).unfocus();
                    Navigator.of(context).pop();
                  },
                  icon: Icon(
                    CupertinoIcons.left_chevron,
                    color: cs.secondary,
                  )),
              Expanded(
                  child: StreamBuilder(
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    return Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            FirebaseAuth.instance.currentUser!.isAnonymous
                                ? "Welcome, Guest"
                                : "Welcome, ${snapshot.data!['name']}",
                            style: TextStyle(
                                color: cs.secondary,
                                fontSize: 24,
                                fontWeight: FontWeight.bold),
                          ),
                          Text(
                            "Let's find an event for you.",
                            style: TextStyle(
                                color: cs.secondary,
                                fontSize: 16,
                                fontWeight: FontWeight.w400),
                          )
                        ],
                      ),
                    );
                  } else {
                    return Container();
                  }
                },
                stream: FirebaseFirestore.instance
                    .collection('users')
                    .doc(FirebaseAuth.instance.currentUser!.uid)
                    .snapshots(),
              )),
              IconButton(
                  onPressed: () {},
                  icon: Icon(
                    CupertinoIcons.bell,
                    color: cs.secondary,
                  ))
            ],
          ),

          /// Search Bar
          Card(
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            color: cs.onSurface,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Row(
              children: [
                Expanded(
                    child: Padding(
                  padding: const EdgeInsets.all(5),
                  child: SizedBox(
                    height: 40,
                    child: TextField(
                      autofocus: true,
                      controller: textEditingController,
                      style: TextStyle(color: cs.onSecondary, fontSize: 16),
                      decoration: const InputDecoration(
                          enabledBorder: InputBorder.none,
                          border: InputBorder.none,
                          errorBorder: InputBorder.none,
                          hintText: "Search...",
                          prefixIcon: Icon(
                            Icons.search,
                            size: 20,
                          ),
                          disabledBorder: InputBorder.none),
                      onChanged: (val) {
                        searchResult(val);
                      },
                    ),
                  ),
                )),
                CupertinoButton(
                  onPressed: () {
                    filterView(context);
                  },
                  padding: const EdgeInsets.all(5),
                  child: const Icon(CupertinoIcons.slider_horizontal_3),
                )
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Wrap(
              runSpacing: 8,
              alignment: WrapAlignment.start,
              crossAxisAlignment: WrapCrossAlignment.start,
              spacing: 8,
              children: List.generate(
                  docs.length,
                  (index) => EventCard(
                        documentSnapshot: docs[index],
                      )),
            ),
          )
        ],
      ),
    );
  }

  searchResult(String val) async {
    logger.d(val);
    if (val.isNotEmpty) {
      try {
        QuerySnapshot streamQuery =
            await FirebaseFirestore.instance.collection('event').get();
        logger.d("All Docs  ${streamQuery.docs}");
        docs = [];
        var list = streamQuery.docs;
        if(sselectedSortBy.isNotEmpty){
          list = list
              .where((s) => s['eventname']
              .toLowerCase()
              .toString()
              .contains(val.toLowerCase()))
              .toList();
        }
        // if(sselectedOperational.isNotEmpty){
        //   list = list
        //       .where((s) => sselectedOperational.any((x) => s['Type'].any((y) => y.toLowerCase().contains(x.toLowerCase()))))
        //       .toList();
        // }
        // if(sselectedRatings.isNotEmpty){
        //   list = list
        //       .where((s) => sselectedOperational.any((x) => s['Include'].any((y) => y.toLowerCase().contains(x.toLowerCase()))))
        //       .toList();
        // }
        if(sselectedIncludes.isNotEmpty){
          list = list
              .where((s) => sselectedOperational.any((x) => s['Include'].any((y) => y.toLowerCase().contains(x.toLowerCase()))))
              .toList();
        }
        setState(() {
          docs = list
              .where((s) => s['eventname']
                  .toLowerCase()
                  .toString()
                  .contains(val.toLowerCase()))
              .toList();
        });
      } catch (err) {
        logger.e("ERR $err");
      }
    } else {
      setState(() {
        docs = [];
      });
    }
  }

  reset() {
    setState(() {
      sselectedIncludes = [];
      sselectedRatings.clear();
      sselectedSortBy.clear();
      sselectedOperational.clear();
      sselectedType.clear();
    });
  }

  filterView(context) {
    List<String> selectedSortBy = [];
    List<String> selectedType = [];
    List<String> selectedOperational = [];
    List<String> selectedRatings = [];
    List<String> selectedIncludes = [];
    return showModalBottomSheet(
      context: context,
      barrierColor: Colors.black.withOpacity(0.5),
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) => Wrap(
            children: [
              Container(
                decoration: BoxDecoration(
                    color: cs.onPrimary,
                    borderRadius:
                        const BorderRadius.vertical(top: Radius.circular(24))),
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Filter Place",
                          style: TextStyle(
                              color: cs.onSecondary,
                              fontSize: 18,
                              fontWeight: FontWeight.w600),
                        ),
                        OutlinedButton.icon(
                          onPressed: () {
                            reset();
                            Navigator.of(context).pop();
                          },
                          label: const Text(
                            "Reset",
                            style: TextStyle(fontSize: 14),
                          ),
                          icon: const Icon(
                            CupertinoIcons.refresh,
                            size: 16,
                          ),
                        )
                      ],
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Text(
                      "Sort By",
                      style: TextStyle(
                          color: cs.primary,
                          fontSize: 16,
                          fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    SizedBox(
                      width: size.width,
                      child: Wrap(
                        spacing: 5,
                        runSpacing: 5,
                        children: List.generate(
                            sortBy.length,
                            (index) => GestureDetector(
                                  onTap: () {
                                    if (selectedSortBy
                                        .contains(sortBy[index])) {
                                      setState(() {
                                        selectedSortBy.remove(sortBy[index]);
                                      });
                                    } else {
                                      setState(() {
                                        selectedSortBy.add(sortBy[index]);
                                      });
                                    }
                                  },
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 10, vertical: 5),
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(5),
                                        border: Border.all(
                                            color: selectedSortBy
                                                    .contains(sortBy[index])
                                                ? cs.secondary
                                                : cs.secondaryContainer
                                                    .withOpacity(0.5),
                                            width: 2)),
                                    child: Text(
                                      sortBy[index],
                                      style: TextStyle(
                                          color: selectedSortBy
                                                  .contains(sortBy[index])
                                              ? cs.secondary
                                              : cs.secondaryContainer
                                                  .withOpacity(0.5),
                                          fontSize: 14,
                                          fontWeight: FontWeight.w500),
                                    ),
                                  ),
                                )),
                      ),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Text(
                      "Type",
                      style: TextStyle(
                          color: cs.primary,
                          fontSize: 16,
                          fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    SizedBox(
                      width: size.width,
                      child: Wrap(
                        spacing: 5,
                        runSpacing: 5,
                        children: List.generate(
                            type.length,
                            (index) => GestureDetector(
                                  onTap: () {
                                    if (selectedType.contains(type[index])) {
                                      setState(() {
                                        selectedType.remove(type[index]);
                                      });
                                    } else {
                                      setState(() {
                                        selectedType.add(type[index]);
                                      });
                                    }
                                  },
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 10, vertical: 5),
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(5),
                                        border: Border.all(
                                            color: selectedType
                                                    .contains(type[index])
                                                ? cs.secondary
                                                : cs.secondaryContainer
                                                    .withOpacity(0.5),
                                            width: 2)),
                                    child: Text(
                                      type[index],
                                      style: TextStyle(
                                          color:
                                              selectedType.contains(type[index])
                                                  ? cs.secondary
                                                  : cs.secondaryContainer
                                                      .withOpacity(0.5),
                                          fontSize: 14,
                                          fontWeight: FontWeight.w500),
                                    ),
                                  ),
                                )),
                      ),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Text(
                      "Operational",
                      style: TextStyle(
                          color: cs.primary,
                          fontSize: 16,
                          fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    SizedBox(
                      width: size.width,
                      child: Wrap(
                        spacing: 5,
                        runSpacing: 5,
                        children: List.generate(
                            operational.length,
                            (index) => GestureDetector(
                                  onTap: () {
                                    if (selectedOperational
                                        .contains(operational[index])) {
                                      setState(() {
                                        selectedOperational
                                            .remove(operational[index]);
                                      });
                                    } else {
                                      setState(() {
                                        selectedOperational
                                            .add(operational[index]);
                                      });
                                    }
                                  },
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 10, vertical: 5),
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(5),
                                        border: Border.all(
                                            color: selectedOperational.contains(
                                                    operational[index])
                                                ? cs.secondary
                                                : cs.secondaryContainer
                                                    .withOpacity(0.5),
                                            width: 2)),
                                    child: Text(
                                      operational[index],
                                      style: TextStyle(
                                          color: selectedOperational
                                                  .contains(operational[index])
                                              ? cs.secondary
                                              : cs.secondaryContainer
                                                  .withOpacity(0.5),
                                          fontSize: 14,
                                          fontWeight: FontWeight.w500),
                                    ),
                                  ),
                                )),
                      ),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Text(
                      "Ratings",
                      style: TextStyle(
                          color: cs.primary,
                          fontSize: 16,
                          fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    SizedBox(
                      width: size.width,
                      child: Wrap(
                        spacing: 5,
                        runSpacing: 5,
                        children: List.generate(
                            ratings.length,
                            (index) => GestureDetector(
                                  onTap: () {
                                    if (selectedRatings
                                        .contains(ratings[index])) {
                                      setState(() {
                                        selectedRatings.remove(ratings[index]);
                                      });
                                    } else {
                                      setState(() {
                                        selectedRatings.add(ratings[index]);
                                      });
                                    }
                                  },
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 10, vertical: 5),
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(5),
                                        border: Border.all(
                                            color: selectedRatings
                                                    .contains(ratings[index])
                                                ? cs.secondary
                                                : cs.secondaryContainer
                                                    .withOpacity(0.5),
                                            width: 2)),
                                    child: Text(
                                      ratings[index],
                                      style: TextStyle(
                                          color: selectedRatings
                                                  .contains(ratings[index])
                                              ? cs.secondary
                                              : cs.secondaryContainer
                                                  .withOpacity(0.5),
                                          fontSize: 14,
                                          fontWeight: FontWeight.w500),
                                    ),
                                  ),
                                )),
                      ),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Text(
                      "Include",
                      style: TextStyle(
                          color: cs.primary,
                          fontSize: 16,
                          fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    SizedBox(
                      width: size.width,
                      child: Wrap(
                        spacing: 5,
                        runSpacing: 5,
                        children: List.generate(
                            includes.length,
                            (index) => GestureDetector(
                                  onTap: () {
                                    if (selectedIncludes
                                        .contains(includes[index])) {
                                      setState(() {
                                        selectedIncludes
                                            .remove(includes[index]);
                                      });
                                    } else {
                                      setState(() {
                                        selectedIncludes.add(includes[index]);
                                      });
                                    }
                                  },
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 10, vertical: 5),
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(5),
                                        border: Border.all(
                                            color: selectedIncludes
                                                    .contains(includes[index])
                                                ? cs.secondary
                                                : cs.secondaryContainer
                                                    .withOpacity(0.5),
                                            width: 2)),
                                    child: Text(
                                      includes[index],
                                      style: TextStyle(
                                          color: selectedIncludes
                                                  .contains(includes[index])
                                              ? cs.secondary
                                              : cs.secondaryContainer
                                                  .withOpacity(0.5),
                                          fontSize: 14,
                                          fontWeight: FontWeight.w500),
                                    ),
                                  ),
                                )),
                      ),
                    ),
                    Divider(
                      height: 32,
                      thickness: 1,
                      color: cs.secondaryContainer.withOpacity(0.5),
                    ),
                    SizedBox(
                      width: size.width,
                      child: CupertinoButton(
                        color: cs.primary,
                        onPressed: () {
                          setState(() {
                            sselectedIncludes = selectedIncludes;
                            sselectedRatings = selectedRatings;
                            sselectedSortBy = selectedSortBy;
                            sselectedOperational = selectedOperational;
                            sselectedType = selectedType;
                          });
                          Navigator.of(context).pop();
                        },
                        child: Text("Apply",
                            style: TextStyle(
                                color: cs.onPrimary,
                                fontWeight: FontWeight.w600,
                                fontSize: 18)),
                      ),
                    )
                  ],
                ),
              )
            ],
          ),
        );
      },
    );
  }
}
