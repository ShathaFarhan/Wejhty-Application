import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:wejhty/routes/page_route.dart';
import 'package:wejhty/view/dashboard/home/bookOrder/order_item.dart';

import '../../../../helper/global_data.dart';

class OrderListScreen extends StatelessWidget {
  static const String routeName = '/orderListScreen';

  const OrderListScreen({Key? key}) : super(key: key);

  Future<bool> _onWillPop() async {
    Navigator.pushNamedAndRemoveUntil(
        GlobalData.navigatorKey.currentState!.context,
        PageRoutes.dashboard,
        (route) => false);
    return false; //<-- SEE HERE
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        backgroundColor: cs.primary,
        appBar: AppBar(
          title: Text(
            "My Bookings",
            style: TextStyle(color: cs.secondary),
          ),
          leading: IconButton(
              onPressed: () {
                _onWillPop();
              },
              icon: Icon(
                CupertinoIcons.left_chevron,
                color: cs.secondary,
              )),
          iconTheme: IconThemeData(color: cs.secondary),
        ),
        /// Fetch the orders list
        body: StreamBuilder<QuerySnapshot>(
          stream: FirebaseFirestore.instance
              .collection("orders")
              .where("uid", isEqualTo: FirebaseAuth.instance.currentUser!.uid)
              .snapshots(),
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              if (snapshot.data != null) {
                return ListView.builder(
                  padding: const EdgeInsets.all(8),
                    itemBuilder: (context, index) =>
                        OrderItem(documentSnapshot: snapshot.data!.docs[index]),
                    itemCount: snapshot.data!.docs.length);
              }
              return Container();
            } else {
              return Container();
            }
          },
        ),
      ),
    );
  }
}
