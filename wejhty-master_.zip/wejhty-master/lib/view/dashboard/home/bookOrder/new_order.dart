import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cool_stepper/cool_stepper.dart';
import 'package:dropdown_textfield/dropdown_textfield.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:map_location_picker/map_location_picker.dart';
import 'package:pinput/pinput.dart';
import 'package:wejhty/helper/global_data.dart';
import 'package:wejhty/routes/page_route.dart';
import 'package:wejhty/services/booking_service.dart';
import '../../../../main.dart';
import '../../account/map_location_screen.dart';
import '../components/event_card.dart';

class NewOrderScreen extends StatefulWidget {
  final DateTime dateTime;
  final DocumentSnapshot documentSnapshot;

  const NewOrderScreen(
      {Key? key, required this.documentSnapshot, required this.dateTime})
      : super(key: key);

  @override
  State<NewOrderScreen> createState() => _NewOrderScreenState();
}

class _NewOrderScreenState extends State<NewOrderScreen> {
  /// Basic Details
  final _formKey = GlobalKey<FormState>();
  static final TextEditingController _otpController = TextEditingController();
  static final TextEditingController _emailController = TextEditingController();
  static final TextEditingController _phoneController = TextEditingController();
  static final TextEditingController _nameController = TextEditingController();
  static final TextEditingController _locationController =
      TextEditingController();
  static final SingleValueDropDownController _genderController =
      SingleValueDropDownController();
  Map? location = {"lat": 24.196312, "long": 45.853587};
  late DateTime selectedDate;
  DocumentSnapshot? selectedTransport;
  String selectedTrans = '';

  /// Payment Details
  String? selectedPayment;
  final _paymentFormKey = GlobalKey<FormState>();
  static final TextEditingController _cardNameController =
      TextEditingController();
  static final TextEditingController _cardNumberController =
      TextEditingController();
  static final TextEditingController _cardExpiryDateController =
      TextEditingController();
  static final TextEditingController _cardCVVController =
      TextEditingController();
  String cardNumber = '';

  onLocationSelect(Location? latLng, String? address) {
    logger.d("$location $address");
    if (latLng != null && address != null) {
      _locationController.text = address;
      location = {"lat": latLng.lat, "long": latLng.lng};
      logger.d(location);
    }
  }

  clearData() {
    _otpController.clear();
    _emailController.clear();
    _phoneController.clear();
    _nameController.clear();
    _locationController.clear();
    _genderController.clearDropDown();
    _cardNameController.clear();
    _cardNumberController.clear();
    _cardExpiryDateController.clear();
    _cardCVVController.clear();
    selectedPayment = null;
  }

  @override
  void initState() {
    clearData();
    selectedDate = widget.dateTime;
    super.initState();
  }

  onVehicleSelect(DocumentSnapshot? documentSnapshot) {
    setState(() {
      selectedTransport = documentSnapshot;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cs.primary,
      appBar: AppBar(
        title: Text(
          "Book Event",
          style: TextStyle(color: cs.secondary),
        ),
        leading: IconButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            icon: Icon(
              CupertinoIcons.left_chevron,
              color: cs.secondary,
            )),
        iconTheme: IconThemeData(color: cs.secondary),
      ),
      body: CoolStepper(
        onCompleted: () {},
        showErrorSnackbar: true,
        config: CoolStepperConfig(
          headerColor: cs.onSurface,
          backText: "Previous",
          nextText: "Continue",
          finalText: "Confirm",
          titleTextStyle: TextStyle(
              color: cs.primary, fontWeight: FontWeight.w600, fontSize: 16),
          subtitleTextStyle: TextStyle(
              color: cs.secondaryContainer,
              fontWeight: FontWeight.w500,
              fontSize: 14),
        ),
        steps: [
          // Transport
          CoolStep(
            title: "Select Transport (Optional)",
            subtitle: "Select transportation information for event.",
            content: StreamBuilder<QuerySnapshot>(
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  if (snapshot.data != null) {
                    return Column(
                      children: [
                        ...List.generate(
                            snapshot.data!.docs.length,
                            (index) => Card(
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8)),
                                  color: cs.secondary.withOpacity(0.3),
                                  elevation: 5,
                                  margin: const EdgeInsets.only(bottom: 16),
                                  child: Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      ClipRRect(
                                        borderRadius:
                                            const BorderRadius.horizontal(
                                                left: Radius.circular(8)),
                                        child: Image.network(
                                          snapshot.data!.docs[index]['image'],
                                          width: 120,
                                          height: 80,
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                      Expanded(
                                          child: Padding(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 10),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceEvenly,
                                          children: [
                                            Text(
                                                snapshot.data!.docs[index]
                                                    ['vehicletype'],
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                                style: TextStyle(
                                                    color: cs.onSecondary,
                                                    fontSize: 20,
                                                    fontWeight: FontWeight.w600,
                                                    letterSpacing: 1.0)),
                                            const SizedBox(
                                              height: 10,
                                            ),
                                            // Text("Txn Id: ${documentSnapshot['txn_id']}",
                                            //     maxLines: 1,
                                            //     overflow: TextOverflow.ellipsis,
                                            //     style: TextStyle(
                                            //         color: cs.onSecondary,
                                            //         fontSize: 14,
                                            //         fontWeight: FontWeight.w500)),
                                            Row(
                                              children: [
                                                Expanded(
                                                    child: Text(
                                                        "\$${snapshot.data!.docs[index]['price']}/${snapshot.data!.docs[index]['price_duration']}",
                                                        maxLines: 1,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        style: TextStyle(
                                                            color: cs.secondary,
                                                            fontSize: 16,
                                                            fontWeight:
                                                                FontWeight.w500,
                                                            letterSpacing:
                                                                1.0))),
                                              ],
                                            )
                                          ],
                                        ),
                                      )),
                                      Radio(
                                        value: snapshot.data!.docs[index].id,
                                        onChanged: (val) {
                                          setState(() {
                                            selectedTransport =
                                                snapshot.data!.docs[index];
                                            selectedTrans = val!;
                                          });
                                        },
                                        groupValue: selectedTrans,
                                      )
                                    ],
                                  ),
                                ))
                      ],
                    );
                  }
                  return Container();
                } else {
                  return const Center(
                    child: CircularProgressIndicator(),
                  );
                }
              },
              stream: FirebaseFirestore.instance
                  .collection('transportation')
                  .snapshots(),
            ),
            validation: () {
              return null;
            },
          ),
          // Contact Information
          CoolStep(
            title: "Contact Information",
            subtitle: "Please fill contact information.",
            content: Form(
                key: _formKey,
                child: Card(
                  elevation: 8,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(24)),
                  color: cs.onPrimary,
                  margin: const EdgeInsets.only(top: 24),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        vertical: 32, horizontal: 16),
                    child: Column(
                      children: [
                        SizedBox(
                          height: 40,
                          child: CupertinoTextField(
                            placeholder: "Full Name",
                            controller: _nameController,
                            keyboardType: TextInputType.name,
                            textInputAction: TextInputAction.next,
                            decoration: BoxDecoration(
                                border: Border.all(color: cs.primary, width: 2),
                                borderRadius: BorderRadius.circular(20)),
                          ),
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        SizedBox(
                          height: 40,
                          child: CupertinoTextField(
                            placeholder: "Email Address",
                            controller: _emailController,
                            keyboardType: TextInputType.emailAddress,
                            textInputAction: TextInputAction.next,
                            decoration: BoxDecoration(
                                border: Border.all(color: cs.primary, width: 2),
                                borderRadius: BorderRadius.circular(20)),
                          ),
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        SizedBox(
                          height: 40,
                          child: CupertinoTextField(
                            placeholder: "Phone",
                            controller: _phoneController,
                            maxLength: 10,
                            keyboardType: TextInputType.phone,
                            textInputAction: TextInputAction.next,
                            decoration: BoxDecoration(
                                border: Border.all(color: cs.primary, width: 2),
                                borderRadius: BorderRadius.circular(20)),
                          ),
                        ),
                        SizedBox(
                          height: size.height * 0.03,
                        ),
                        SizedBox(
                          height: 40,
                          child: DropDownTextField(
                            controller: _genderController,
                            clearOption: false,
                            textStyle:
                                TextStyle(color: cs.onSecondary, fontSize: 16),
                            listTextStyle: TextStyle(
                                color: cs.secondaryContainer,
                                fontWeight: FontWeight.w500,
                                fontSize: 16),
                            textFieldDecoration: InputDecoration(
                              border: OutlineInputBorder(
                                  borderSide:
                                      BorderSide(width: 2, color: cs.primary),
                                  borderRadius: BorderRadius.circular(20)),
                              fillColor: cs.secondaryContainer,
                              hintText: "Gender",
                              hintStyle: TextStyle(
                                  color: cs.secondaryContainer.withOpacity(0.3),
                                  fontWeight: FontWeight.w500,
                                  fontSize: 14),
                              enabledBorder: OutlineInputBorder(
                                  borderSide:
                                      BorderSide(width: 2, color: cs.primary),
                                  borderRadius: BorderRadius.circular(20)),
                              labelStyle: TextStyle(
                                  color: cs.secondaryContainer.withOpacity(0.3),
                                  fontWeight: FontWeight.w500,
                                  fontSize: 14),
                            ),
                            enableSearch: false,
                            dropDownList: const [
                              DropDownValueModel(name: 'Male', value: "Male"),
                              DropDownValueModel(
                                  name: 'Female', value: "Female"),
                            ],
                            onChanged: (val) {},
                          ),
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        SizedBox(
                          height: 40,
                          child: CupertinoTextField(
                            placeholder: "Location",
                            controller: _locationController,
                            readOnly: true,
                            onTap: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => MapLocationScreen(
                                        function: onLocationSelect,
                                        location: location),
                                  ));
                            },
                            suffix: Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 5),
                              child: Icon(
                                CupertinoIcons.location_solid,
                                size: 20,
                                color: cs.primary,
                              ),
                            ),
                            keyboardType: TextInputType.phone,
                            textInputAction: TextInputAction.next,
                            decoration: BoxDecoration(
                                border: Border.all(color: cs.primary, width: 2),
                                borderRadius: BorderRadius.circular(20)),
                          ),
                        ),
                      ],
                    ),
                  ),
                )),
            validation: () {
              if (_nameController.text.isEmpty ||
                  _emailController.text.isEmpty ||
                  _phoneController.text.isEmpty ||
                  _genderController.dropDownValue!.name.isEmpty ||
                  _locationController.text.isEmpty) {
                return 'All fields are mandatory.';
              }
              return null;
            },
          ),
          // Payment Method
          CoolStep(
              title: "Select Payment Method",
              subtitle: "Please select the payment method.",
              content: Column(
                children: [
                  const SizedBox(
                    height: 24,
                  ),
                  SizedBox(
                    width: size.width,
                    child: GestureDetector(
                      onTap: () {
                        setState(() {
                          selectedPayment = 'paypal';
                        });
                      },
                      child: Card(
                        elevation: 8,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8)),
                        color: cs.onPrimary,
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Row(
                            children: [
                              Expanded(
                                  child: Text(
                                "Paypal",
                                style: TextStyle(
                                    color: cs.secondaryContainer,
                                    fontSize: 20,
                                    fontWeight: FontWeight.w500),
                              )),
                              Radio(
                                  value: "paypal",
                                  groupValue: selectedPayment,
                                  onChanged: (val) {
                                    setState(() {
                                      selectedPayment = val;
                                    });
                                  })
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 16,
                  ),
                  SizedBox(
                    width: size.width,
                    child: GestureDetector(
                      onTap: () {
                        setState(() {
                          selectedPayment = 'applePay';
                        });
                      },
                      child: Card(
                        elevation: 8,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8)),
                        color: cs.onPrimary,
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Row(
                            children: [
                              Expanded(
                                  child: Text(
                                "Apple Pay",
                                style: TextStyle(
                                    color: cs.secondaryContainer,
                                    fontSize: 20,
                                    fontWeight: FontWeight.w500),
                              )),
                              Radio(
                                  value: "applePay",
                                  groupValue: selectedPayment,
                                  onChanged: (val) {
                                    setState(() {
                                      selectedPayment = val;
                                    });
                                  })
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  if (cardNumber.isNotEmpty)
                    const SizedBox(
                      height: 16,
                    ),
                  if (cardNumber.isNotEmpty)
                    SizedBox(
                      width: size.width,
                      child: GestureDetector(
                        onTap: () {
                          setState(() {
                            selectedPayment = 'card';
                          });
                        },
                        child: Card(
                          elevation: 8,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8)),
                          color: cs.onPrimary,
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Row(
                              children: [
                                Expanded(
                                    child: Text(
                                  "XXXX-XXXX-XXXX-${cardNumber!.substring(12, 16)}",
                                  style: TextStyle(
                                      color: cs.secondaryContainer,
                                      fontSize: 20,
                                      fontWeight: FontWeight.w500),
                                )),
                                Radio(
                                    value: "card",
                                    groupValue: selectedPayment,
                                    onChanged: (val) {
                                      setState(() {
                                        selectedPayment = val;
                                      });
                                    })
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  const SizedBox(
                    height: 32,
                  ),
                  CupertinoButton(
                      color: cs.secondary,
                      onPressed: () {
                        showDialog(
                          context: context,
                          builder: (context) => AlertDialog(
                            backgroundColor: cs.onPrimary,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10)),
                            content: Form(
                              key: _paymentFormKey,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(bottom: 5),
                                    child: Text(
                                      "Card Name",
                                      style: TextStyle(
                                          color: cs.primary,
                                          fontWeight: FontWeight.w500,
                                          fontSize: 16),
                                    ),
                                  ),
                                  SizedBox(
                                    height: 40,
                                    child: CupertinoTextField(
                                      placeholder: "Card Name",
                                      controller: _cardNameController,
                                      keyboardType: TextInputType.name,
                                      textInputAction: TextInputAction.next,
                                      style: TextStyle(
                                          color: cs.secondaryContainer
                                              .withOpacity(0.5)),
                                      decoration: BoxDecoration(
                                          border: Border.all(
                                              color: cs.primary, width: 2),
                                          borderRadius:
                                              BorderRadius.circular(20)),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 16,
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(bottom: 5),
                                    child: Text(
                                      "Card Number",
                                      style: TextStyle(
                                          color: cs.primary,
                                          fontWeight: FontWeight.w500,
                                          fontSize: 16),
                                    ),
                                  ),
                                  SizedBox(
                                    height: 40,
                                    child: CupertinoTextField(
                                      placeholder: "Card Number",
                                      controller: _cardNumberController,
                                      keyboardType: TextInputType.number,
                                      textInputAction: TextInputAction.next,
                                      style: TextStyle(
                                          color: cs.secondaryContainer
                                              .withOpacity(0.5)),
                                      decoration: BoxDecoration(
                                          border: Border.all(
                                              color: cs.primary, width: 2),
                                          borderRadius:
                                              BorderRadius.circular(20)),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 16,
                                  ),
                                  Row(
                                    children: [
                                      Expanded(
                                          child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Padding(
                                            padding: const EdgeInsets.only(
                                                bottom: 5),
                                            child: Text(
                                              "Expiry Date",
                                              style: TextStyle(
                                                  color: cs.primary,
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 16),
                                            ),
                                          ),
                                          SizedBox(
                                            height: 40,
                                            child: CupertinoTextField(
                                              placeholder: "Expiry Date",
                                              controller:
                                                  _cardExpiryDateController,
                                              keyboardType:
                                                  TextInputType.datetime,
                                              textInputAction:
                                                  TextInputAction.next,
                                              style: TextStyle(
                                                  color: cs.secondaryContainer
                                                      .withOpacity(0.5)),
                                              decoration: BoxDecoration(
                                                  border: Border.all(
                                                      color: cs.primary,
                                                      width: 2),
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          20)),
                                            ),
                                          )
                                        ],
                                      )),
                                      const SizedBox(
                                        width: 10,
                                      ),
                                      Expanded(
                                          child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Padding(
                                            padding: const EdgeInsets.only(
                                                bottom: 5),
                                            child: Text(
                                              "CVV",
                                              style: TextStyle(
                                                  color: cs.primary,
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 16),
                                            ),
                                          ),
                                          SizedBox(
                                            height: 40,
                                            child: CupertinoTextField(
                                              placeholder: "CVV",
                                              controller: _cardCVVController,
                                              keyboardType:
                                                  TextInputType.number,
                                              maxLength: 3,
                                              textInputAction:
                                                  TextInputAction.next,
                                              style: TextStyle(
                                                  color: cs.secondaryContainer
                                                      .withOpacity(0.5)),
                                              decoration: BoxDecoration(
                                                  border: Border.all(
                                                      color: cs.primary,
                                                      width: 2),
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          20)),
                                            ),
                                          ),
                                        ],
                                      ))
                                    ],
                                  ),
                                  const SizedBox(
                                    height: 20,
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      CupertinoButton(
                                        onPressed: () {
                                          Navigator.of(context).pop();
                                        },
                                        color: cs.onSurface,
                                        padding: EdgeInsets.symmetric(
                                            horizontal: size.width * 0.05,
                                            vertical: 5),
                                        child: Text(
                                          "Cancel",
                                          style: TextStyle(
                                              color: cs.onSecondaryContainer),
                                        ),
                                      ),
                                      CupertinoButton(
                                          onPressed: () {
                                            if (_cardNumberController
                                                    .text.isEmpty ||
                                                _cardNameController
                                                    .text.isEmpty ||
                                                _cardExpiryDateController
                                                    .text.isEmpty ||
                                                _cardCVVController
                                                    .text.isEmpty) {
                                              EasyLoading.showToast(
                                                  "All fields are mandatory.",
                                                  duration: const Duration(
                                                      seconds: 1));
                                            } else {
                                              setState(() {
                                                cardNumber =
                                                    _cardNumberController.text;
                                              });
                                              Navigator.of(context).pop();
                                            }
                                          },
                                          color: cs.secondary,
                                          padding: EdgeInsets.symmetric(
                                              horizontal: size.width * 0.05,
                                              vertical: 5),
                                          child: Text(
                                            "Continue",
                                            style:
                                                TextStyle(color: cs.onPrimary),
                                          )),
                                    ],
                                  )
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                      child: Text(
                        "Add New Card",
                        style: TextStyle(color: cs.onPrimary, fontSize: 16),
                      ))
                ],
              ),
              validation: () {
                if (selectedPayment == null) {
                  return "Please select payment method.";
                }
                return null;
              }),
          // Review Summary
          CoolStep(
              title: "Review Summary",
              subtitle: "Please verify the order items and payment methods.",
              content: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  EventCard(documentSnapshot: widget.documentSnapshot),
                  const SizedBox(
                    height: 16,
                  ),
                  if (selectedTransport != null)
                    Card(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8)),
                      color: cs.secondary.withOpacity(0.3),
                      elevation: 5,
                      margin: const EdgeInsets.only(bottom: 16),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          ClipRRect(
                            borderRadius: const BorderRadius.horizontal(
                                left: Radius.circular(8)),
                            child: Image.network(
                              selectedTransport!['image'],
                              width: 120,
                              height: 80,
                              fit: BoxFit.cover,
                            ),
                          ),
                          Expanded(
                              child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 10),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Text(selectedTransport!['vehicletype'],
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                        color: cs.onSecondary,
                                        fontSize: 20,
                                        fontWeight: FontWeight.w600,
                                        letterSpacing: 1.0)),
                                const SizedBox(
                                  height: 10,
                                ),
                                // Text("Txn Id: ${documentSnapshot['txn_id']}",
                                //     maxLines: 1,
                                //     overflow: TextOverflow.ellipsis,
                                //     style: TextStyle(
                                //         color: cs.onSecondary,
                                //         fontSize: 14,
                                //         fontWeight: FontWeight.w500)),
                                Row(
                                  children: [
                                    Expanded(
                                        child: Text(
                                            "\$${selectedTransport!['price']}/${selectedTransport!['price_duration']}",
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: TextStyle(
                                                color: cs.secondary,
                                                fontSize: 16,
                                                fontWeight: FontWeight.w500,
                                                letterSpacing: 1.0))),
                                  ],
                                )
                              ],
                            ),
                          )),
                        ],
                      ),
                    ),
                  Card(
                    elevation: 8,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8)),
                    color: cs.onPrimary,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 8),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Contact Info:",
                            style: TextStyle(
                                color: cs.primary,
                                fontSize: 14,
                                fontWeight: FontWeight.w600),
                          ),
                          const SizedBox(
                            height: 5,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                "Name:",
                                style: TextStyle(
                                    color: cs.onSecondaryContainer,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 16),
                              ),
                              Text(
                                _nameController.text,
                                style: TextStyle(
                                    color: cs.onSecondary,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 16),
                              ),
                            ],
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                "Email:",
                                style: TextStyle(
                                    color: cs.onSecondaryContainer,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 16),
                              ),
                              Text(
                                _emailController.text,
                                style: TextStyle(
                                    color: cs.onSecondary,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 16),
                              ),
                            ],
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                "Mobile:",
                                style: TextStyle(
                                    color: cs.onSecondaryContainer,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 16),
                              ),
                              Text(
                                _phoneController.text,
                                style: TextStyle(
                                    color: cs.onSecondary,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 16),
                              ),
                            ],
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "Address:",
                                style: TextStyle(
                                    color: cs.onSecondaryContainer,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 16),
                              ),
                              Expanded(
                                child: Text(
                                  _locationController.text,
                                  textAlign: TextAlign.end,
                                  style: TextStyle(
                                      color: cs.onSecondary,
                                      fontWeight: FontWeight.w500,
                                      fontSize: 16),
                                ),
                              )
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Card(
                    elevation: 8,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8)),
                    color: cs.onPrimary,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 8),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Booking:",
                            style: TextStyle(
                                color: cs.primary,
                                fontSize: 14,
                                fontWeight: FontWeight.w600),
                          ),
                          const SizedBox(
                            height: 5,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                "Booking For",
                                style: TextStyle(
                                    color: cs.onSecondaryContainer,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 16),
                              ),
                              Text(
                                "\$${GlobalData.normalFormat.format(selectedDate)}",
                                style: TextStyle(
                                    color: cs.onSecondary,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 16),
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Card(
                    elevation: 8,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8)),
                    color: cs.onPrimary,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 8),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Total Payment:",
                            style: TextStyle(
                                color: cs.primary,
                                fontSize: 14,
                                fontWeight: FontWeight.w600),
                          ),
                          const SizedBox(
                            height: 5,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                "Booking Amount:",
                                style: TextStyle(
                                    color: cs.onSecondaryContainer,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 16),
                              ),
                              Text(
                                "\$${widget.documentSnapshot['price']}",
                                style: TextStyle(
                                    color: cs.onSecondary,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 16),
                              ),
                            ],
                          ),
                          if (selectedTransport != null)
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  "Transport:",
                                  style: TextStyle(
                                      color: cs.onSecondaryContainer,
                                      fontWeight: FontWeight.w500,
                                      fontSize: 16),
                                ),
                                Text(
                                  "\$${selectedTransport!['price']}",
                                  style: TextStyle(
                                      color: cs.onSecondary,
                                      fontWeight: FontWeight.w500,
                                      fontSize: 16),
                                ),
                              ],
                            ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                "Tax:",
                                style: TextStyle(
                                    color: cs.onSecondaryContainer,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 16),
                              ),
                              Text(
                                "\$0",
                                style: TextStyle(
                                    color: cs.onSecondary,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 16),
                              ),
                            ],
                          ),
                          Divider(
                              color: cs.onSurface, thickness: 1, height: 16),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                "Total:",
                                style: TextStyle(
                                    color: cs.onSecondaryContainer,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 16),
                              ),
                              Text(
                                "\$${widget.documentSnapshot['price']}",
                                style: TextStyle(
                                    color: cs.onSecondary,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 16),
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Card(
                    elevation: 8,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8)),
                    color: cs.onPrimary,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 8),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Payment Method:",
                            style: TextStyle(
                                color: cs.primary,
                                fontSize: 14,
                                fontWeight: FontWeight.w600),
                          ),
                          const SizedBox(
                            height: 5,
                          ),
                          Row(
                            children: [
                              Expanded(
                                  child: Text(
                                selectedPayment == "paypal"
                                    ? "Paypal"
                                    : selectedPayment == "applePay"
                                        ? "Apple Pay"
                                        : selectedPayment == "card"
                                            ? "XXXX-XXXX-XXXX-${cardNumber.substring(12, 16)}"
                                            : "",
                                style: TextStyle(
                                    color: cs.secondaryContainer,
                                    fontSize: 18,
                                    fontWeight: FontWeight.w500),
                              )),
                              Radio(
                                  value: selectedPayment,
                                  groupValue: selectedPayment,
                                  onChanged: (val) {})
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 16,
                  )
                ],
              ),
              validation: () {
                return null;
              }),
          // OTP Confirmation
          CoolStep(
              title: "Confirm Payment",
              subtitle: "Enter OTP below to confirm your payment.",
              content: SizedBox(
                width: size.width,
                child: Card(
                  elevation: 8,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8)),
                  color: cs.onPrimary,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        const SizedBox(
                          height: 24,
                        ),
                        Text(
                          "Enter PIN Bellow \nTO Confirm Your Payment",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              color: cs.secondaryContainer,
                              fontSize: 20,
                              fontWeight: FontWeight.w600),
                        ),
                        const SizedBox(
                          height: 42,
                        ),
                        Pinput(
                          defaultPinTheme: defaultPinTheme,
                          controller: _otpController,
                          focusedPinTheme: defaultPinTheme.copyDecorationWith(
                            border: Border.all(
                                color: const Color.fromRGBO(114, 178, 238, 1)),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          submittedPinTheme: defaultPinTheme.copyDecorationWith(
                            color: const Color.fromRGBO(234, 239, 243, 1),
                          ),
                          validator: (s) {
                            return s == '1234' ? null : 'Pin is incorrect';
                          },
                          pinputAutovalidateMode:
                              PinputAutovalidateMode.onSubmit,
                          showCursor: true,
                          onCompleted: (pin) => logger.e(pin),
                        ),
                        const SizedBox(height: 42),
                        CupertinoButton(
                          onPressed: () {
                            if (_otpController.text != "1234") {
                              EasyLoading.showToast("Enter a valid OTP 1234.",
                                  duration: const Duration(seconds: 1));
                            } else {
                              var payload = {
                                "eventId": widget.documentSnapshot.id,
                                "Thumbnail":
                                    widget.documentSnapshot['Thumbnail'],
                                "eventname":
                                    widget.documentSnapshot['eventname'],
                                "price": widget.documentSnapshot['price'],
                                "price_duration":
                                    widget.documentSnapshot['price_duration'],
                                "name": _nameController.text,
                                "email": _emailController.text,
                                "mobile": _phoneController.text,
                                "gender": _genderController.dropDownValue!.name,
                                "address": _locationController.text,
                                "location": location,
                                "payment_method": selectedPayment,
                                "txn_id":
                                    "${DateTime.parse(GlobalData.intFormat.format(DateTime.now())).millisecondsSinceEpoch}",
                                "status": "confirmed",
                                "uid": FirebaseAuth.instance.currentUser!.uid,
                                "booking_date":
                                    selectedDate.millisecondsSinceEpoch,
                                "book_date":
                                GlobalData.normalFormat.format(selectedDate),
                                "created_at": DateTime.now()
                              };
                              if (selectedTransport != null) {
                                payload['transport'] = {
                                  'id': selectedTransport!.id,
                                  "image": selectedTransport!['image'],
                                  "vehicletype":
                                      selectedTransport!['vehicletype'],
                                  "vehiclenumber":
                                      selectedTransport!['vehiclenumber'],
                                  "price": selectedTransport!['price'],
                                  "price_duration":
                                      selectedTransport!['price_duration'],
                                };
                              }
                              BookingService.updateUserData(payload)
                                  .then((value) {
                                if (value == true) {
                                  showBottom(context);
                                }
                              });
                            }
                          },
                          color: cs.secondary,
                          padding: EdgeInsets.symmetric(
                              horizontal: size.width * 0.05, vertical: 5),
                          child: Text(
                            "Verify PIN",
                            style: TextStyle(color: cs.onPrimary),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              validation: () {
                return null;
              }),
        ],
      ),
    );
  }

  showBottom(context) {
    return showModalBottomSheet(
      context: context,
      isScrollControlled: false,
      isDismissible: false,
      backgroundColor: cs.secondary,
      builder: (context) => BottomSheet(
        onClosing: () {},
        backgroundColor: cs.secondary,
        builder: (context) => Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                "Congratulation",
                style: TextStyle(
                    color: cs.onSecondary,
                    fontSize: 20,
                    fontWeight: FontWeight.w600),
              ),
              Divider(
                thickness: 1,
                height: 32,
                color: cs.secondaryContainer.withOpacity(0.1),
              ),
              Text(
                "You have successfully booked your event",
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: cs.secondaryContainer,
                    fontWeight: FontWeight.w500,
                    fontSize: 16),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Icon(
                  CupertinoIcons.checkmark_alt_circle_fill,
                  color: cs.secondaryContainer.withOpacity(0.4),
                  size: 42,
                ),
              ),
              CupertinoButton(
                onPressed: () {
                  Navigator.pushNamedAndRemoveUntil(
                      context, PageRoutes.orderListScreen, (route) => false);
                },
                color: cs.primary,
                padding: EdgeInsets.symmetric(
                    horizontal: size.width * 0.05, vertical: 5),
                child: Text(
                  "Continue",
                  style: TextStyle(color: cs.onPrimary),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  final defaultPinTheme = PinTheme(
    width: 56,
    height: 56,
    textStyle: const TextStyle(
        fontSize: 20,
        color: Color.fromRGBO(30, 60, 87, 1),
        fontWeight: FontWeight.w600),
    decoration: BoxDecoration(
      border: Border.all(color: const Color.fromRGBO(234, 239, 243, 1)),
      borderRadius: BorderRadius.circular(8),
    ),
  );
}
