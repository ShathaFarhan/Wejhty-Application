import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../../../helper/global_data.dart';

class OrderItem extends StatelessWidget {
  final DocumentSnapshot documentSnapshot;

  const OrderItem({Key? key, required this.documentSnapshot}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      color: cs.secondary.withOpacity(0.3),
      elevation: 5,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          ClipRRect(
            borderRadius:
                const BorderRadius.horizontal(left: Radius.circular(8)),
            child: Image.network(
              documentSnapshot['Thumbnail'],
              width: 120,
              height: 80,
              fit: BoxFit.cover,
            ),
          ),
          Expanded(
              child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(documentSnapshot['eventname'],
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        color: cs.onSecondary,
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 1.0)),
                const SizedBox(
                  height: 5,
                ),
                Text("Txn Id: ${documentSnapshot['txn_id']}",
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        color: cs.onSecondary,
                        fontSize: 14,
                        fontWeight: FontWeight.w500)),
                Row(
                  children: [
                    Expanded(
                        child: Text(
                            "For: ${GlobalData.normalFormat.format(DateTime.fromMillisecondsSinceEpoch(documentSnapshot['booking_date']))}",
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                                color: cs.secondary,
                                fontSize: 14,
                                fontWeight: FontWeight.w400,
                                letterSpacing: 1.0))),
                    CupertinoButton(
                      onPressed: documentSnapshot['status'] == "canceled"
                          ? null
                          : () {
                        cancelWarning(context);
                      },
                      padding: const EdgeInsets.all(5),
                      minSize: 30,
                      child: Text(
                        documentSnapshot['status'] == "canceled"
                            ? "Canceled"
                            : "Cancel",
                        style: TextStyle(
                            color: documentSnapshot['status'] == "canceled"
                                ? cs.onPrimary
                                : cs.onSecondary,
                            fontSize: 14),
                      ),
                    )
                  ],
                )
              ],
            ),
          )),
        ],
      ),
    );
  }

  cancelWarning(context) {
    showCupertinoDialog(
        context: context,
        builder: (context) => CupertinoAlertDialog(
          title: Text(
            "Warning",
            style: TextStyle(color: cs.error),
          ),
          content: const Text("Do you really want to cancel this order?"),
          actions: [
            CupertinoButton(
                child: Text("Yes", style: TextStyle(color: cs.error)),
                onPressed: () {
                  FirebaseFirestore.instance.collection('orders').doc(documentSnapshot.id).update({
                    "status": "canceled"
                  });
                  Navigator.of(context).pop();
                }),
            CupertinoButton(
                child: const Text("No"),
                onPressed: () {
                  Navigator.of(context).pop();
                }),
          ],
        ),
        barrierDismissible: true);
  }
}
