import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../../../../helper/global_data.dart';

class TransportCard extends StatefulWidget {
  final DocumentSnapshot documentSnapshot;
  final Function onSelect;

  const TransportCard(
      {Key? key, required this.documentSnapshot, required this.onSelect})
      : super(key: key);

  @override
  State<TransportCard> createState() => _TransportCardState();
}

class _TransportCardState extends State<TransportCard> {
  static bool isSelected = false;

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      color: cs.secondary.withOpacity(0.3),
      elevation: 5,
      margin: const EdgeInsets.only(bottom: 16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          ClipRRect(
            borderRadius:
                const BorderRadius.horizontal(left: Radius.circular(8)),
            child: Image.network(
              widget.documentSnapshot['image'],
              width: 120,
              height: 80,
              fit: BoxFit.cover,
            ),
          ),
          Expanded(
              child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Text(widget.documentSnapshot['vehicletype'],
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        color: cs.onSecondary,
                        fontSize: 20,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 1.0)),
                const SizedBox(
                  height: 10,
                ),
                // Text("Txn Id: ${documentSnapshot['txn_id']}",
                //     maxLines: 1,
                //     overflow: TextOverflow.ellipsis,
                //     style: TextStyle(
                //         color: cs.onSecondary,
                //         fontSize: 14,
                //         fontWeight: FontWeight.w500)),
                Row(
                  children: [
                    Expanded(
                        child: Text(
                            "\$${widget.documentSnapshot['price']}/${widget.documentSnapshot['price_duration']}",
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                                color: cs.secondary,
                                fontSize: 16,
                                fontWeight: FontWeight.w500,
                                letterSpacing: 1.0))),
                  ],
                )
              ],
            ),
          )),
          Checkbox(
              value: isSelected,
              onChanged: (val) {
                setState(() {
                  isSelected = val!;
                });
              })
        ],
      ),
    );
  }
}
