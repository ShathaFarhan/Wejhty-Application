import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:wejhty/helper/global_data.dart';
import 'package:wejhty/view/dashboard/home/all_event_screen.dart';
import 'package:wejhty/view/dashboard/home/components/event_card.dart';
import 'package:wejhty/view/dashboard/home/components/event_heading.dart';
import 'package:wejhty/view/dashboard/home/components/feature_card.dart';
import 'package:wejhty/view/dashboard/home/searchFilter/search_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  static final List<String> categories = [
    "All",
    "Indoor",
    "Outdoor",
    "Mix"
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cs.primary,
      body: ListView(
        shrinkWrap: false,
        padding: const EdgeInsets.symmetric(vertical: 16),
        children: [
          /// Heading
          Row(
            children: [
              Expanded(
                  child: StreamBuilder(
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    return Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            FirebaseAuth.instance.currentUser!.isAnonymous ? "Welcome, Guest" : "Welcome, ${snapshot.data!['name']}",
                            style: TextStyle(
                                color: cs.secondary,
                                fontSize: 24,
                                fontWeight: FontWeight.bold),
                          ),
                          Text(
                            "Let's find an event for you.",
                            style: TextStyle(
                                color: cs.secondary,
                                fontSize: 16,
                                fontWeight: FontWeight.w400),
                          )
                        ],
                      ),
                    );
                  } else {
                    return Container();
                  }
                },
                stream: FirebaseFirestore.instance
                    .collection('users')
                    .doc(FirebaseAuth.instance.currentUser!.uid)
                    .snapshots(),
              )),
              IconButton(
                  onPressed: () {},
                  icon: Icon(
                    CupertinoIcons.bell,
                    color: cs.secondary,
                  ))
            ],
          ),

          /// Search Bar
          GestureDetector(
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const SearchScreen(),
                  ));
            },
            child: Card(
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              color: cs.onSurface,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
              child: Row(
                children: [
                  Expanded(
                      child: Padding(
                    padding: const EdgeInsets.only(left: 8),
                    child: Row(
                      children: const [
                        Icon(
                          CupertinoIcons.search,
                          size: 20,
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Text("Search...")
                      ],
                    ),
                  )),
                  const CupertinoButton(
                    onPressed: null,
                    padding: EdgeInsets.all(5),
                    child: Icon(CupertinoIcons.slider_horizontal_3),
                  )
                ],
              ),
            ),
          ),

          // Categories Menu
          SizedBox(
            width: size.width,
            height: 80,
            child: ListView(
              scrollDirection: Axis.horizontal,
              shrinkWrap: true,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
              children: List.generate(
                  categories.length,
                  (index) => CupertinoButton(
                        padding: const EdgeInsets.all(0),
                        onPressed: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => AllEventScreen(type: categories[index]),
                              ));
                        },
                        child: ConstrainedBox(
                          constraints: const BoxConstraints(minWidth: 100),
                          child: Card(
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(30)),
                            child: Center(
                              child: Text(
                                categories[index],
                                style: TextStyle(
                                    color: cs.secondaryContainer,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 16),
                              ),
                            ),
                          ),
                        ),
                      )),
            ),
          ),
          const SizedBox(
            height: 5,
          ),

          /// Featured
          EventHeading(
              heading: "Featured",
              onPressed: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const AllEventScreen(type: "Featured"),
                    ));
              }),
          SizedBox(
            width: size.width,
            height: size.width * 0.4 + 160,
            child: StreamBuilder(
              stream: FirebaseFirestore.instance.collection("event").where("Is_featured", isEqualTo: true).snapshots(),
              builder: (context, snapshot) {
                if(snapshot.hasData){
                  if(snapshot.data != null){
                    return ListView(
                      scrollDirection: Axis.horizontal,
                      shrinkWrap: true,
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 0),
                      children: List.generate(
                          snapshot.data!.docs.length, (index) => FeatureCard(documentSnapshot: snapshot.data!.docs[index],)),
                    );
                  }else{
                    return Container();
                  }
                }else{
                  return Container();
                }
              },
            ),
          ),
          const SizedBox(
            height: 16,
          ),

          /// Popular
          EventHeading(
              heading: "Popular Events",
              onPressed: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const AllEventScreen(type: "Popular"),
                    ));
              }),
          SizedBox(
            width: size.width,
            height: 170,
            child: StreamBuilder(
              stream: FirebaseFirestore.instance.collection("event").where("Is_popular", isEqualTo: true).snapshots(),
              builder: (context, snapshot) {
                if(snapshot.hasData){
                  if(snapshot.data != null){
                    return ListView(
                      scrollDirection: Axis.horizontal,
                      shrinkWrap: true,
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 0),
                      children: List.generate(
                          snapshot.data!.docs.length, (index) => EventCard(documentSnapshot: snapshot.data!.docs[index],)),
                    );
                  }else{
                    return Container();
                  }
                }else{
                  return Container();
                }
              },
            ),
          ),
        ],
      ),
    );
  }
}
