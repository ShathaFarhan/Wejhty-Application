
import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:wejhty/helper/global_data.dart';
import 'package:wejhty/main.dart';
import 'package:wejhty/routes/page_route.dart';

class AuthService {

  Future<void> signInAnonymously() async {
    try {
      EasyLoading.show(status: 'loading...');
      UserCredential userCredential = await FirebaseAuth.instance.signInAnonymously();
      EasyLoading.dismiss();
      if(userCredential.user != null){
        logger.d('Signed in as anonymous user with UID: ${userCredential.user!.uid}');
        Navigator.pushNamedAndRemoveUntil(GlobalData.navigatorKey.currentState!.context, PageRoutes.dashboard, (route) => false,);
      }else{
        EasyLoading.showToast('Failed to sign in anonymously.', duration: const Duration(seconds: 1));
      }
    } on FirebaseAuthException catch (e) {
      logger.e('Failed to sign in anonymously: $e');
      EasyLoading.showToast('Failed to sign in anonymously.', duration: const Duration(seconds: 1));
    } catch (e) {
      EasyLoading.dismiss();
      EasyLoading.showToast('Failed to sign in.', duration: const Duration(seconds: 1));
      logger.e(e);
    }
  }


  Future<void> signUpWithEmailAndPassword(
      String email, String password, String name) async {
    try {
      EasyLoading.show(status: 'loading...');
      UserCredential userCredential;
      if(FirebaseAuth.instance.currentUser != null){
        if(FirebaseAuth.instance.currentUser!.isAnonymous){
          userCredential = await FirebaseAuth.instance.currentUser!.linkWithCredential(
            EmailAuthProvider.credential(email: email, password: password),
          );
        }else{
          FirebaseAuth.instance.signOut();
          userCredential = await FirebaseAuth.instance
              .createUserWithEmailAndPassword(email: email, password: password);
        }
      }else{
        userCredential = await FirebaseAuth.instance
            .createUserWithEmailAndPassword(email: email, password: password);
      }
      // The user is signed up.

      // Add the user's details to a Firestore collection.
      await FirebaseFirestore.instance.collection('users').doc(userCredential.user?.uid).set({
        'name': name,
        'email': email,
        'created_at': DateTime.now().toUtc().toString(),
        'avatar': 'https://firebasestorage.googleapis.com/v0/b/wejhty-app.appspot.com/o/user-avatar.png?alt=media&token=5c7b4808-d566-4f96-9d60-f67e8a03e53c'
      });
      EasyLoading.dismiss();
      Navigator.pushNamedAndRemoveUntil(GlobalData.navigatorKey.currentState!.context, PageRoutes.dashboard, (route) => false,);
    } on FirebaseAuthException catch (e) {
      EasyLoading.dismiss();
      if (e.code == 'weak-password') {
        logger.e('The password provided is too weak.');
        EasyLoading.showToast('The password provided is too weak.', duration: const Duration(seconds: 1));
      } else if (e.code == 'email-already-in-use') {
        logger.e('The account already exists for that email.');
        EasyLoading.showToast('The account already exists for that email.', duration: const Duration(seconds: 1));
      }
    } catch (e) {
      EasyLoading.dismiss();
      EasyLoading.showToast('Failed to submit.', duration: const Duration(seconds: 1));
      logger.e(e);
    }
  }

  Future<void> signInWithEmailAndPassword(String email, String password) async {
    try {
      EasyLoading.show(status: 'loading...');
      UserCredential userCredential = await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      EasyLoading.dismiss();
      if(userCredential.user != null){
        Navigator.pushNamedAndRemoveUntil(GlobalData.navigatorKey.currentState!.context, PageRoutes.dashboard, (route) => false,);
      }else {
        EasyLoading.showToast(
            'Failed to login.', duration: const Duration(seconds: 1));
      }
      // The user is signed in.
    } on FirebaseAuthException catch (e) {
      EasyLoading.dismiss();
      if (e.code == 'user-not-found') {
        logger.e('No user found for that email.');
        EasyLoading.showToast('No user found for that email.', duration: const Duration(seconds: 1));
      } else if (e.code == 'wrong-password') {
        logger.e('Wrong password provided for that user.');
        EasyLoading.showToast('Wrong password provided for that user.', duration: const Duration(seconds: 1));
      }
    } catch (e) {
      EasyLoading.dismiss();
      EasyLoading.showToast('Failed to login.', duration: const Duration(seconds: 1));
      logger.e(e);
    }
  }

  Future<bool> resetPassword(String email) async {
    try {
      EasyLoading.show(status: 'loading...');
      await FirebaseAuth.instance.sendPasswordResetEmail(
        email: email,
      );
      EasyLoading.dismiss();
      return true;
      // The password reset email is sent.
    } on FirebaseAuthException catch (e) {
      EasyLoading.dismiss();
      if (e.code == 'user-not-found') {
        logger.e('No user found for that email.');
        EasyLoading.showToast('No user found for that email.', duration: const Duration(seconds: 1));
      }
    } catch (e) {
      EasyLoading.dismiss();
      EasyLoading.showToast('Failed to submit.', duration: const Duration(seconds: 1));
      logger.e(e);
    }
    return false;
  }

  Future<DocumentSnapshot<Map<String, dynamic>>?> getCurrentUser() async {
    try {
      EasyLoading.show(status: 'loading...');
      DocumentSnapshot<Map<String, dynamic>> documentSnapshot = await FirebaseFirestore.instance.collection('users').doc(FirebaseAuth.instance.currentUser!.uid).get();
      EasyLoading.dismiss();
      if(documentSnapshot.exists){
        return documentSnapshot;
      }else{
        return null;
      }
    } catch (e) {
      logger.d('Failed to get user data by UID: $e');
      EasyLoading.dismiss();
      return null;
    }
  }

  Future<void> updateUserData(Map<String, dynamic> data) async {
    try {
      EasyLoading.show(status: 'loading...');
      await FirebaseFirestore.instance.collection('users').doc(FirebaseAuth.instance.currentUser!.uid).update(data);
      logger.d('User data updated successfully');
      EasyLoading.dismiss();
      EasyLoading.showToast('User data updated successfully.', duration: const Duration(seconds: 1));
    } catch (e) {
      logger.d('Failed to update user data: $e');
      EasyLoading.dismiss();
      EasyLoading.showToast('Failed to update.', duration: const Duration(seconds: 1));
    }
  }

  uploadProfileImage(File file) async {
    FirebaseStorage storage = FirebaseStorage.instance;
//Create a reference to the location you want to upload to in firebase
    TaskSnapshot uploadTask = await storage.ref(file.path).putFile(file);
    String? url = await uploadTask.ref.getDownloadURL();
    updateUserData({"avatar": url});
    return true;
  }


}