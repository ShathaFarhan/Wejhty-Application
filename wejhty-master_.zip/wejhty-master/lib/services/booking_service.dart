
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:wejhty/main.dart';

class BookingService {

  static Future<bool> updateUserData(Map<String, dynamic> data) async {
    try {
      EasyLoading.show(status: 'loading...');
      await FirebaseFirestore.instance.collection('orders').add(data);
      logger.d('Order Placed successfully');
      EasyLoading.dismiss();
      EasyLoading.showToast('Order Placed successfully.', duration: const Duration(seconds: 1));
      return true;
    } catch (e) {
      logger.d('Failed to place order data: $e');
      EasyLoading.dismiss();
      EasyLoading.showToast('Failed to place order.', duration: const Duration(seconds: 1));
      return false;
    }
  }

}