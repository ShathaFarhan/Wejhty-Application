
import 'package:wejhty/view/auth/login/login_screen.dart';
import 'package:wejhty/view/auth/register/register_screen.dart';
import 'package:wejhty/view/auth/resetPassword/reset_password_screen.dart';
import 'package:wejhty/view/dashboard/account/map_location_screen.dart';
import 'package:wejhty/view/dashboard/account/update_profile.dart';
import 'package:wejhty/view/dashboard/dashboard_screen.dart';
import 'package:wejhty/view/dashboard/home/bookOrder/order_list_screen.dart';

import '../view/auth/auth_screen.dart';

class PageRoutes {
  static const String auth = AuthScreen.routeName;
  static const String login = LoginScreen.routeName;
  static const String register = RegisterScreen.routeName;
  static const String resetPassword = ResetPasswordScreen.routeName;
  static const String dashboard = DashboardScreen.routeName;
  static const String orderListScreen = OrderListScreen.routeName;
  static const String profileUpdate = ProfileUpdateScreen.routeName;

  static var routes = {
    PageRoutes.auth: (context) => const AuthScreen(),
    PageRoutes.login: (context) => const LoginScreen(),
    PageRoutes.register: (context) => const RegisterScreen(),
    PageRoutes.resetPassword: (context) => const ResetPasswordScreen(),
    PageRoutes.dashboard: (context) => const DashboardScreen(),
    PageRoutes.orderListScreen: (context) => const OrderListScreen(),
    PageRoutes.profileUpdate: (context) => const ProfileUpdateScreen(),
  };
}