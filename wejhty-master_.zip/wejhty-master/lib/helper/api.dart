
class API {
  /// Base Url
  static String baseUrl = "";

}
