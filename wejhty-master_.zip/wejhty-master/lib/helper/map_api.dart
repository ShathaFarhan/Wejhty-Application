class APIKeys {
  static String androidApiKey = "AIzaSyDBkk-x5XQ8fT68eJMWwOU6IT1VwgoSU4g";
  static String iosApiKey = "AIzaSyCRcaxAqagsXzMV7xGbMWpOY3UY9YQe--k";
  // static String iosApiKey = "AIzaSyDBkk-x5XQ8fT68eJMWwOU6IT1VwgoSU4g";
}