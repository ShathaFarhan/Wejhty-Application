
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

import '../main.dart';

class PreferencesHelper {
  static late SharedPreferences preferences;

  static String tokenKey = "token";
  static String userKey = "user";
  static String settingsKey = "settings";
  static String boardingKey = "boarding";

  static bool getBoardingStatus() {
    if (preferences.containsKey(boardingKey)) {
      return preferences.getBool(boardingKey)!;
    } else {
      return false;
    }
  }

  static saveBoardingStatus(bool status) {
    preferences.setBool(boardingKey, status);
  }

  static removeBoardingStatus() {
    preferences.remove(boardingKey);
  }

  // User
  static dynamic getUser() {
    if (preferences.containsKey(userKey)) {
      logger.d(("User ${preferences.getString(userKey)}"));
      return jsonDecode(preferences.getString(userKey)!);
    } else {
      return null;
    }
  }

  static saveUser(user) {
    preferences.setString(userKey, jsonEncode(user));
  }

  static removeUser() {
    preferences.remove(userKey);
    preferences.remove(tokenKey);
  }

  /// Token
  static String? getToken() {
    if (preferences.containsKey(tokenKey)) {
      return preferences.getString(tokenKey);
    } else {
      return null;
    }
  }

  static saveToken(String token) {
    preferences.setString(tokenKey, token);
  }

  static removeToken() {
    preferences.remove(tokenKey);
  }

  static logout() {
    preferences.remove(userKey);
    preferences.remove(tokenKey);
  }
}
