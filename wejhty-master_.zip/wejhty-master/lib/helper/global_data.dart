import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:moment_dart/moment_dart.dart';
import 'package:url_launcher/url_launcher.dart';
import '../main.dart';

ColorScheme cs =
    Theme.of(GlobalData.navigatorKey.currentState!.context).colorScheme;
Size size = MediaQuery.of(GlobalData.navigatorKey.currentState!.context).size;

class GlobalData {
  static final GlobalKey<NavigatorState> navigatorKey =
      GlobalKey<NavigatorState>();
  static GlobalKey<ScaffoldState> drawerScaffoldKey = GlobalKey();
  static String defaultUserAvatar =
      'https://firebasestorage.googleapis.com/v0/b/flexzi-jobs.appspot.com/o/default%2Fuser-avatar.png?alt=media&token=2bae8ada-37de-4f8e-b116-adb393c9fcf3';


  static var emailRegExp = RegExp(
      r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$');
  static var phoneRegExp = RegExp(r'^(?:(?:\+|0{0,2})91(\s*[\ -]\s*)?|[0]?)?[789]\d{9}|(\d[ -]?){10}\d$');
  // Minimum eight characters, at least one letter and one number:
  static var password1RegExp = RegExp(r"^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$");

  // Minimum eight characters, at least one letter, one number and one special character:
  static var password2RegExp = RegExp(r"^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$");

  // Minimum eight characters, at least one uppercase letter, one lowercase letter and one number:
  static var password3RegExp = RegExp(r"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$");

  // Minimum eight characters, at least one uppercase letter, one lowercase letter, one number and one special character:
  static var password4RegExp = RegExp(r"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$");

  static bool notification = false;

  // static OSNotification? currentNotification;
  static final format = DateFormat("d MMMM, yyyy h:mm a");
  static final normalFormat = DateFormat("d MMMM, yyyy");
  static final intFormat = DateFormat("yyyy-mm-dd");

  static getFromNow(date){
    try{
      var dd = DateTime.parse(date).toLocal().toMoment();
      return dd.fromNow(form: UnitStringForm.mid);
    }catch(e){
      logger.e(e);
      return '';
    }
  }

  static String removeAllHtmlTags(String htmlText) {
    RegExp exp = RegExp(r"<[^>]*>", multiLine: true, caseSensitive: true);

    return htmlText.replaceAll(exp, '');
  }

  static failedDialog({required String text}){
    return showCupertinoDialog(context: navigatorKey.currentState!.context, builder: (context) => CupertinoAlertDialog(
      content: Text(text),
      title: const Icon(CupertinoIcons.info_circle),
      actions: [
        CupertinoDialogAction(child: const Text("OK"), onPressed: (){
          Navigator.of(context).pop();
        },)
      ],
    ),);
  }

  static successDialog({required String text}){
    return showCupertinoDialog(context: navigatorKey.currentState!.context, builder: (context) => CupertinoAlertDialog(
      content: Text(text),
      title: const Icon(CupertinoIcons.check_mark_circled),
      actions: [
        CupertinoDialogAction(child: const Text("OK"), onPressed: (){
          Navigator.of(context).pop();
        },)
      ],
    ),);
  }

  static int getDifference(String date) {
    final fDate = DateTime.parse(date);
    final cFDate = DateTime.now();
    logger.d("DAT ${cFDate.difference(fDate).inDays}");
    return cFDate.difference(fDate).inDays;
  }


  static launchPDF(String? url, {String type = "general", String? name}) async {
    try{
      if(url != null){
        await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
      }
    }catch(e){
      logger.e(e);
    }
  }

}

extension StringCasingExtension on String {
  String toCapitalized() => length > 0 ?'${this[0].toUpperCase()}${substring(1).toLowerCase()}':'';
  String toTitleCase() => replaceAll(RegExp(' +'), ' ').split(' ').map((str) => str.toCapitalized()).join(' ');
}