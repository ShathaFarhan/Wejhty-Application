import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:wejhty/routes/page_route.dart';

import 'helper/global_data.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    initializeApp();
    super.initState();
  }

  navigateToHomePage() {
    if(FirebaseAuth.instance.currentUser != null){
      Navigator.pushNamedAndRemoveUntil(context, PageRoutes.dashboard, (route) => false);
    }else{
      Navigator.pushNamedAndRemoveUntil(context, PageRoutes.auth, (route) => false);
    }
  }

  initializeApp() async {
    Timer(const Duration(seconds: 1), () {
      navigateToHomePage();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cs.primary,
      body: SafeArea(
        child: Stack(
          children: [

            SizedBox(
              width: size.width,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Spacer(),
                  Text("Wejhty", style: TextStyle(
                      color: cs.primary,
                      fontSize: 18,
                      fontWeight: FontWeight.bold
                  ),),
                  const SizedBox(height: 16,)
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
